import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
const green = Color(0xFF0E7A5B);
const greenLight = Color(0xFF2BBF8A);
const amber = Color(0xFFF5B301);
const yellow = Color(0xFFFFD54A);
void main() => runApp(const AddaApp());
class Account {
  String id, name, username, bio; bool online;
  Account({required this.id, required this.name, required this.username, this.bio = '', this.online = false});
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'username': username, 'bio': bio};
  static Account fromJson(Map<String, dynamic> j) => Account(id: j['id'], name: j['name'], username: j['username'], bio: j['bio'] ?? '');
}
class Msg {
  String id, from, to, text; bool seen;
  Msg({required this.id, required this.from, required this.to, required this.text, this.seen = false});
  Map<String, dynamic> toJson() => {'id': id, 'from': from, 'to': to, 'text': text, 'seen': seen};
  static Msg fromJson(Map<String, dynamic> j) => Msg(id: j['id'], from: j['from'], to: j['to'], text: j['text'], seen: j['seen'] ?? false);
}
class Req { String id, from, to; Req({required this.id, required this.from, required this.to}); }
class Store extends ChangeNotifier {
  List<Account> accounts = []; List<Msg> messages = []; List<Req> requests = []; List<String> friendPairs = [];
  String? currentId; bool en = false; String theme = 'device'; SharedPreferences? prefs; bool loaded = false;
  String t(String bn, String enTxt) => en ? enTxt : bn;
  Account? get me { for (final a in accounts) { if (a.id == currentId) return a; } return null; }
  bool areFriends(String a, String b) => friendPairs.contains(_pair(a, b));
  String _pair(String a, String b) => a.compareTo(b) < 0 ? '$a|$b' : '$b|$a';
  Future<void> load() async {
    prefs = await SharedPreferences.getInstance();
    final raw = prefs!.getString('adda_data');
    if (raw != null) {
      final j = jsonDecode(raw);
      accounts = (j['accounts'] as List).map((e) => Account.fromJson(e)).toList();
      messages = (j['messages'] as List).map((e) => Msg.fromJson(e)).toList();
      requests = (j['requests'] as List).map((e) => Req(id: e['id'], from: e['from'], to: e['to'])).toList();
      friendPairs = List<String>.from(j['friends'] ?? []); currentId = j['currentId']; en = j['en'] ?? false; theme = j['theme'] ?? 'device';
    }
    loaded = true; notifyListeners();
  }
  Future<void> save() async { if (prefs == null) return; await prefs!.setString('adda_data', jsonEncode({'accounts': accounts.map((a) => a.toJson()).toList(), 'messages': messages.map((m) => m.toJson()).toList(), 'requests': requests.map((r) => {'id': r.id, 'from': r.from, 'to': r.to}).toList(), 'friends': friendPairs, 'currentId': currentId, 'en': en, 'theme': theme})); }
  Future<void> createAccount(String name, String username, String bio) async {
    final clean = username.trim().toLowerCase().replaceAll(' ', '');
    if (name.trim().isEmpty || clean.isEmpty) return;
    if (accounts.any((a) => a.username == clean)) return;
    final a = Account(id: DateTime.now().millisecondsSinceEpoch.toString(), name: name.trim(), username: clean, bio: bio.trim(), online: true);
    accounts.add(a); currentId = a.id; notifyListeners(); await save();
  }
  void enter(String id) { currentId = id; notifyListeners(); save(); }
  void logout() { currentId = null; notifyListeners(); save(); }
  void sendRequest(String to) { final meId = currentId!; if (requests.any((r) => (r.from == meId && r.to == to) || (r.from == to && r.to == meId))) return; requests.add(Req(id: DateTime.now().millisecondsSinceEpoch.toString(), from: meId, to: to)); notifyListeners(); save(); }
  void respond(String reqId, bool accept) { Req? r; for (final x in requests) { if (x.id == reqId) r = x; } if (r == null) return; requests.remove(r); if (accept) friendPairs.add(_pair(r.from, r.to)); notifyListeners(); save(); }
  void unfriend(String other) { friendPairs.remove(_pair(currentId!, other)); notifyListeners(); save(); }
  void sendMessage(String to, String text) { if (text.trim().isEmpty) return; messages.add(Msg(id: DateTime.now().millisecondsSinceEpoch.toString(), from: currentId!, to: to, text: text.trim())); notifyListeners(); save(); }
  void markSeen(String other) { var changed = false; for (final m in messages) { if (m.to == currentId && m.from == other && !m.seen) { m.seen = true; changed = true; } } if (changed) { notifyListeners(); save(); } }
  Future<void> deleteAccount(String id) async { accounts.removeWhere((a) => a.id == id); messages.removeWhere((m) => m.from == id || m.to == id); requests.removeWhere((r) => r.from == id || r.to == id); friendPairs.removeWhere((p) => p.contains(id)); if (currentId == id) currentId = null; notifyListeners(); await save(); }
}
class AddaApp extends StatefulWidget { const AddaApp({super.key}); @override State<AddaApp> createState() => _AddaAppState(); }
class _AddaAppState extends State<AddaApp> {
  final store = Store();
  @override void initState() { super.initState(); store.load(); }
  @override Widget build(BuildContext context) {
    return ListenableBuilder(listenable: store, builder: (context, _) {
      final dark = store.theme == 'dark' || (store.theme == 'device' && MediaQuery.platformBrightnessOf(context) == Brightness.dark);
      return MaterialApp(title: 'Adda', debugShowCheckedModeBanner: false, themeMode: dark ? ThemeMode.dark : ThemeMode.light, theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: green, brightness: Brightness.light), scaffoldBackgroundColor: const Color(0xFFF4F7F5)), darkTheme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: green, brightness: Brightness.dark), scaffoldBackgroundColor: const Color(0xFF101613)), home: !store.loaded ? const Scaffold(body: Center(child: CircularProgressIndicator())) : SplashGate(store: store));
    });
  }
}
class SplashGate extends StatefulWidget { final Store store; const SplashGate({super.key, required this.store}); @override State<SplashGate> createState() => _SplashGateState(); }
class _SplashGateState extends State<SplashGate> {
  bool show = true;
  @override void initState() { super.initState(); Future.delayed(const Duration(milliseconds: 2400), () { if (mounted) setState(() => show = false); }); }
  @override Widget build(BuildContext context) {
    if (show) return Scaffold(body: Container(decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF0B6B4F), Color(0xFF12A070), Color(0xFF7ED957)])), child: const Center(child: Row(mainAxisSize: MainAxisSize.min, children: [Text('a.', style: TextStyle(fontSize: 60, fontWeight: FontWeight.w900, color: Colors.white)), Text('আড্ডা', style: TextStyle(fontSize: 60, fontWeight: FontWeight.w900, color: Colors.white)), Text('.', style: TextStyle(fontSize: 60, fontWeight: FontWeight.w900, color: amber))]))));
    return widget.store.me == null ? AuthScreen(store: widget.store) : HomeScreen(store: widget.store);
  }
}
Widget avatar(String name, bool online, double size) {
  return Container(padding: EdgeInsets.all(online ? 3 : 0), decoration: BoxDecoration(shape: BoxShape.circle, gradient: online ? const LinearGradient(colors: [green, greenLight, yellow]) : null), child: Stack(children: [CircleAvatar(radius: size / 2, backgroundColor: green, child: Text(name.isEmpty ? '?' : name[0], style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold))), if (online) Positioned(right: 0, bottom: 0, child: Container(width: 14, height: 14, decoration: BoxDecoration(color: const Color(0xFF2ECC71), shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2))))]));
}
class AuthScreen extends StatefulWidget { final Store store; const AuthScreen({super.key, required this.store}); @override State<AuthScreen> createState() => _AuthScreenState(); }
class _AuthScreenState extends State<AuthScreen> {
  bool creating = false; final nameC = TextEditingController(); final userC = TextEditingController(); final bioC = TextEditingController();
  @override Widget build(BuildContext context) {
    final s = widget.store;
    return Scaffold(body: ListView(padding: const EdgeInsets.all(20), children: [
      Row(mainAxisAlignment: MainAxisAlignment.end, children: [TextButton(onPressed: () { s.en = !s.en; s.notifyListeners(); s.save(); }, child: Text(s.en ? 'বাং' : 'EN'))]),
      const Row(children: [Text('আড্ডা', style: TextStyle(fontSize: 44, fontWeight: FontWeight.w900, color: green)), Text('.', style: TextStyle(fontSize: 44, fontWeight: FontWeight.w900, color: amber))]),
      const SizedBox(height: 8), Text(s.t('সবার আড্ডায় স্বাগতম', "Welcome to everyone's Adda"), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), const SizedBox(height: 16), Text(s.t('অ্যাকাউন্ট বেছে নিন', 'Choose an account'), style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 8),
      for (final a in s.accounts) Card(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)), child: ListTile(leading: avatar(a.name, true, 48), title: Text(a.name, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text('@${a.username}'), trailing: FilledButton(onPressed: () => s.enter(a.id), child: Text(s.t('ঢুকুন', 'Enter'))))),
      const SizedBox(height: 12), FilledButton(onPressed: () => setState(() => creating = !creating), style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))), child: Text(s.t('নতুন অ্যাকাউন্ট তৈরি করুন', 'Create a new account'))),
      if (creating) ...[const SizedBox(height: 12), TextField(controller: nameC, decoration: InputDecoration(labelText: s.t('নাম', 'Name'), border: const OutlineInputBorder())), const SizedBox(height: 8), TextField(controller: userC, decoration: InputDecoration(labelText: s.t('ইউজারনেম', 'Username'), border: const OutlineInputBorder())), const SizedBox(height: 8), TextField(controller: bioC, decoration: InputDecoration(labelText: s.t('বায়ো', 'Bio'), border: const OutlineInputBorder())), const SizedBox(height: 8), Card(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)), child: ListTile(leading: avatar(nameC.text.isEmpty ? '?' : nameC.text, true, 48), title: Text(nameC.text.isEmpty ? s.t('তোমার নাম', 'Your name') : nameC.text, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text('@${userC.text.isEmpty ? 'username' : userC.text}'))), const SizedBox(height: 8), FilledButton(onPressed: () async { await s.createAccount(nameC.text, userC.text, bioC.text); }, style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))), child: Text(s.t('তৈরি করুন', 'Create')))],
    ]));
  }
}
class HomeScreen extends StatefulWidget { final Store store; const HomeScreen({super.key, required this.store}); @override State<HomeScreen> createState() => _HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen> {
  int tab = 0; Account? chatWith;
  @override Widget build(BuildContext context) {
    final s = widget.store; final me = s.me!;
    if (chatWith != null) return ChatScreen(store: s, me: me, friend: chatWith!, onBack: () => setState(() => chatWith = null));
    Widget body = tab == 0 ? MessagesTab(store: s, me: me, onChat: (a) => setState(() => chatWith = a)) : tab == 1 ? PeopleTab(store: s, me: me, onChat: (a) => setState(() { chatWith = a; tab = 0; })) : ProfileTab(store: s, me: me);
    return Scaffold(body: body, bottomNavigationBar: Container(margin: const EdgeInsets.fromLTRB(16, 0, 16, 16), decoration: BoxDecoration(color: Theme.of(context).colorScheme.surface, borderRadius: BorderRadius.circular(28), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.12), blurRadius: 16, offset: const Offset(0, 4))]), child: ClipRRect(borderRadius: BorderRadius.circular(28), child: BottomNavigationBar(currentIndex: tab, onTap: (i) => setState(() => tab = i), selectedItemColor: green, items: [BottomNavigationBarItem(icon: const Icon(Icons.chat_bubble_outline), label: s.t('মেসেজ', 'Messages')), BottomNavigationBarItem(icon: const Icon(Icons.people_outline), label: s.t('মানুষ', 'People')), BottomNavigationBarItem(icon: const Icon(Icons.person_outline), label: s.t('প্রোফাইল', 'Profile'))]))));
  }
}
Widget chip(String label) => Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: Colors.white.withOpacity(0.22), borderRadius: BorderRadius.circular(20)), child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)));
class MessagesTab extends StatelessWidget { final Store store; final Account me; final void Function(Account) onChat; const MessagesTab({super.key, required this.store, required this.me, required this.onChat}); @override Widget build(BuildContext context) {
  final s = store; final friends = s.accounts.where((a) => a.id != me.id && s.areFriends(me.id, a.id)).toList();
  return ListView(children: [
    Container(margin: const EdgeInsets.fromLTRB(16, 16, 16, 8), padding: const EdgeInsets.all(20), decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: const LinearGradient(colors: [Color(0xFF0B6B4F), Color(0xFF12A070), Color(0xFF7ED957)])), child: Stack(children: [const Positioned(right: 0, bottom: 0, child: Text('আড্ডা', style: TextStyle(fontSize: 48, fontWeight: FontWeight.w900, color: Colors.white24))), Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('আড্ডা', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: Colors.white)), Text(s.t('সবার আড্ডায় স্বাগতম', "Welcome to everyone's Adda"), style: const TextStyle(color: Colors.white)), const SizedBox(height: 10), Wrap(spacing: 8, children: [chip('${friends.length} ${s.t('জন বন্ধু', 'friends')}'), chip('${friends.where((f) => f.online).length} ${s.t('জন অনলাইন', 'online')}')])])])),
    Padding(padding: const EdgeInsets.fromLTRB(16, 12, 16, 4), child: Text(s.t('বন্ধুরা', 'Friends'), style: const TextStyle(fontWeight: FontWeight.bold))),
    SizedBox(height: 76, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16), children: friends.map((f) => Padding(padding: const EdgeInsets.only(right: 14), child: InkWell(onTap: () => onChat(f), child: Column(children: [avatar(f.name, f.online, 56), const SizedBox(height: 4), Text(f.name.split(' ').first, style: const TextStyle(fontSize: 12))])))).toList())),
    const Divider(),
    for (final f in friends) Builder(builder: (_) { final msgs = s.messages.where((m) => (m.from == me.id && m.to == f.id) || (m.from == f.id && m.to == me.id)).toList(); final last = msgs.isEmpty ? null : msgs.last; final unread = msgs.where((m) => m.to == me.id && !m.seen).length; return Container(color: unread > 0 ? const Color(0xFFE6F5EE) : null, child: ListTile(leading: avatar(f.name, f.online, 48), title: Text(f.name, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(last == null ? s.t('চ্যাট শুরু করুন', 'Start chatting') : last.text, maxLines: 1), trailing: unread > 0 ? CircleAvatar(radius: 11, backgroundColor: Colors.red, child: Text('$unread', style: const TextStyle(color: Colors.white, fontSize: 12))) : null, onTap: () => onChat(f))); }),
  ]);
}}
class PeopleTab extends StatefulWidget { final Store store; final Account me; final void Function(Account) onChat; const PeopleTab({super.key, required this.store, required this.me, required this.onChat}); @override State<PeopleTab> createState() => _PeopleTabState(); }
class _PeopleTabState extends State<PeopleTab> { String q = ''; @override Widget build(BuildContext context) {
  final s = widget.store; final me = widget.me; final incoming = s.requests.where((r) => r.to == me.id).toList(); final others = s.accounts.where((a) => a.id != me.id && (q.isEmpty || a.name.toLowerCase().contains(q.toLowerCase()) || a.username.toLowerCase().contains(q.toLowerCase()))).toList();
  return ListView(padding: const EdgeInsets.all(16), children: [
    TextField(onChanged: (v) => setState(() => q = v), decoration: InputDecoration(labelText: s.t('নাম / ইউজারনেম দিয়ে খুঁজুন', 'Search by name / username'), border: const OutlineInputBorder())),
    if (incoming.isNotEmpty) ...[const SizedBox(height: 12), Text(s.t('ফ্রেন্ড রিকোয়েস্ট এসেছে', 'Friend requests'), style: const TextStyle(fontWeight: FontWeight.bold))],
    for (final r in incoming) Builder(builder: (_) { Account? from; for (final a in s.accounts) { if (a.id == r.from) from = a; } if (from == null) return const SizedBox(); final f2 = from; return ListTile(leading: avatar(f2.name, f2.online, 48), title: Text(f2.name), trailing: Row(mainAxisSize: MainAxisSize.min, children: [TextButton(onPressed: () => s.respond(r.id, true), child: Text(s.t('গ্রহণ', 'Accept'))), TextButton(onPressed: () => s.respond(r.id, false), child: Text(s.t('বাদ', 'Reject')))])); }),
    const SizedBox(height: 12), Text(s.t('মানুষ', 'People'), style: const TextStyle(fontWeight: FontWeight.bold)),
    for (final a in others) ListTile(leading: avatar(a.name, a.online, 48), title: Text(a.name, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text('@${a.username}'), trailing: s.areFriends(me.id, a.id) ? FilledButton(onPressed: () => widget.onChat(a), child: Text(s.t('মেসেজ', 'Message'))) : s.requests.any((r) => r.from == me.id && r.to == a.id) ? Text(s.t('পাঠানো হয়েছে', 'Sent'), style: const TextStyle(color: Colors.grey)) : FilledButton(onPressed: () => s.sendRequest(a.id), child: Text(s.t('রিকোয়েস্ট', 'Request')))),
  ]);
}}
class ProfileTab extends StatelessWidget { final Store store; final Account me; const ProfileTab({super.key, required this.store, required this.me}); @override Widget build(BuildContext context) {
  final s = store; final friends = s.accounts.where((a) => a.id != me.id && s.areFriends(me.id, a.id)).length;
  return ListView(padding: const EdgeInsets.all(16), children: [
    Row(children: [avatar(me.name, true, 64), const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(me.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), Text('@${me.username}'), Text(s.t('এখন অনলাইনে আছে', 'Online now'), style: const TextStyle(color: green))]))]),
    const SizedBox(height: 8), Text(me.bio.isEmpty ? '' : me.bio), Text('$friends ${s.t('বন্ধু', 'friends')}'),
    const SizedBox(height: 16), Text(s.t('সেটিংস', 'Settings'), style: const TextStyle(fontWeight: FontWeight.bold)),
    Card(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)), child: Column(children: [ListTile(title: Text(s.t('থিম', 'Theme')), subtitle: Text(s.t('লাইট / ডার্ক / ডিভাইস', 'Light / Dark / Device')), trailing: Row(mainAxisSize: MainAxisSize.min, children: [TextButton(onPressed: () { s.theme = 'light'; s.notifyListeners(); s.save(); }, child: const Text('Light')), TextButton(onPressed: () { s.theme = 'dark'; s.notifyListeners(); s.save(); }, child: const Text('Dark')), TextButton(onPressed: () { s.theme = 'device'; s.notifyListeners(); s.save(); }, child: const Text('Device'))])), ListTile(title: Text(s.t('ভাষা', 'Language')), subtitle: Text(s.en ? 'English' : 'বাংলা'), trailing: Row(mainAxisSize: MainAxisSize.min, children: [TextButton(onPressed: () { s.en = false; s.notifyListeners(); s.save(); }, child: const Text('বাংলা')), TextButton(onPressed: () { s.en = true; s.notifyListeners(); s.save(); }, child: const Text('English'))]))])),
    const SizedBox(height: 12), Text(s.t('অ্যাকাউন্ট', 'Account'), style: const TextStyle(fontWeight: FontWeight.bold)),
    Card(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)), child: Column(children: [ListTile(title: Text(s.t('অ্যাকাউন্ট বদলান', 'Switch account')), trailing: const Icon(Icons.chevron_right), onTap: () => s.logout()), ListTile(title: Text(s.t('লগআউট', 'Logout')), trailing: const Icon(Icons.chevron_right), onTap: () => s.logout())])),
    const SizedBox(height: 12), Text(s.t('বিপজ্জনক এলাকা', 'Danger zone'), style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.red)),
    Card(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)), child: ListTile(title: Text(s.t('অ্যাকাউন্ট মুছুন', 'Delete account'), style: const TextStyle(color: Colors.red)), subtitle: Text(s.t('স্থায়ীভাবে মুছে যাবে', 'Will be deleted permanently')), trailing: const Icon(Icons.chevron_right), onTap: () async { final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(title: Text(s.t('অ্যাকাউন্ট মুছুন?', 'Delete account?')), content: Text(s.t('এই অ্যাকাউন্টের সব মেসেজ ও বন্ধুত্ব মুছে যাবে।', 'All messages and friendships for this account will be deleted.')), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: Text(s.t('বাতিল', 'Cancel'))), FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(s.t('মুছুন', 'Delete')))])); if (ok == true) s.deleteAccount(me.id); })),
  ]);
}}
class ChatScreen extends StatefulWidget { final Store store; final Account me; final Account friend; final VoidCallback onBack; const ChatScreen({super.key, required this.store, required this.me, required this.friend, required this.onBack}); @override State<ChatScreen> createState() => _ChatScreenState(); }
class _ChatScreenState extends State<ChatScreen> {
  final textC = TextEditingController();
  @override
  void initState() {
    super.initState();
    widget.store.markSeen(widget.friend.id);
  }
  @override
  Widget build(BuildContext context) {
    final s = widget.store;
    final me = widget.me;
    final f = widget.friend;
    final msgs = s.messages.where((m) => (m.from == me.id && m.to == f.id) || (m.from == f.id && m.to == me.id)).toList();
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(icon: const Icon(Icons.arrow_back), onPressed: widget.onBack),
        title: Row(children: [avatar(f.name, f.online, 40), const SizedBox(width: 10), Text(f.name, style: const TextStyle(fontWeight: FontWeight.bold))]),
        actions: [
          IconButton(icon: const Icon(Icons.call), onPressed: () { Navigator.push(context, MaterialPageRoute(builder: (_) => CallScreen(store: s, me: me, friend: f, kind: 'audio'))); }),
          IconButton(icon: const Icon(Icons.videocam), onPressed: () { Navigator.push(context, MaterialPageRoute(builder: (_) => CallScreen(store: s, me: me, friend: f, kind: 'video'))); }),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(12),
              children: msgs.map((m) {
                final mine = m.from == me.id;
                return Align(
                  alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 3),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(26),
                      gradient: mine ? const LinearGradient(colors: [green, greenLight]) : null,
                      color: mine ? null : Theme.of(context).colorScheme.surfaceContainerHighest,
                    ),
                    child: Text(m.text, style: TextStyle(color: mine ? Colors.white : null)),
                  ),
                );
              }).toList(),
            ),
          ),
          Container(
            margin: const EdgeInsets.all(12),
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              borderRadius: BorderRadius.circular(28),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 12)],
            ),
            child: Row(
              children: [
                Expanded(child: TextField(controller: textC, decoration: InputDecoration(hintText: s.t('মেসেজ লিখুন', 'Write a message'), border: InputBorder.none, contentPadding: const EdgeInsets.symmetric(horizontal: 12)))),
                FilledButton(
                  onPressed: () { s.sendMessage(f.id, textC.text); textC.clear(); },
                  child: Text(s.t('পাঠান', 'Send')),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
class CallScreen extends StatefulWidget { final Store store; final Account me; final Account friend; final String kind; const CallScreen({super.key, required this.store, required this.me, required this.friend, required this.kind}); @override State<CallScreen> createState() => _CallScreenState(); }
class _CallScreenState extends State<CallScreen> { int sec = 0; bool muted = false; @override void initState() { super.initState(); Future.doWhile(() async { await Future.delayed(const Duration(seconds: 1)); if (!mounted) return false; setState(() => sec++); return true; }); } @override Widget build(BuildContext context) {
  final s = widget.store;
  return Scaffold(body: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [avatar(widget.friend.name, true, 96), const SizedBox(height: 16), Text(widget.friend.name, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), Text(widget.kind == 'video' ? s.t('ভিডিও কল', 'Video call') : s.t('ভয়েস কল', 'Voice call')), Text('${(sec ~/ 60).toString().padLeft(2, '0')}:${(sec % 60).toString().padLeft(2, '0')}', style: const TextStyle(fontSize: 20)), const SizedBox(height: 12), Padding(padding: const EdgeInsets.all(16), child: Text(s.t('টেস্ট সিস্টেম: দুই পাশে অ্যাপ খোলা থাকলে কল সংযোগ হবে। আসল দুই ডিভাইসের কল পেতে হোস্টেড সার্ভার লাগবে।', 'Test system: both sides must have the app open. A hosted server is needed for real two-device calls.'), textAlign: TextAlign.center)), const SizedBox(height: 20), Row(mainAxisAlignment: MainAxisAlignment.center, children: [IconButton.filled(onPressed: () => setState(() => muted = !muted), icon: Icon(muted ? Icons.mic_off : Icons.mic)), const SizedBox(width: 12), IconButton.filled(onPressed: () => Navigator.pop(context), style: IconButton.styleFrom(backgroundColor: Colors.red), icon: const Icon(Icons.call_end, color: Colors.white))])])));
}}

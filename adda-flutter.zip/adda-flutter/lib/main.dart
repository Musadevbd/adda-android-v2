import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

const green = Color(0xFF0E7A5B);
const greenLight = Color(0xFF2BBF8A);
const amber = Color(0xFFF5B301);
const yellow = Color(0xFFFFD54A);

void main() => runApp(const AddaApp());

class Account {
  String id, name, username, bio;
  bool online;
  Account({required this.id, required this.name, required this.username, this.bio = '', this.online = false});
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'username': username, 'bio': bio};
  static Account fromJson(Map<String, dynamic> j) => Account(id: j['id'], name: j['name'], username: j['username'], bio: j['bio'] ?? '');
}

class Msg {
  String id, from, to, text;
  bool seen;
  Msg({required this.id, required this.from, required this.to, required this.text, this.seen = false});
  Map<String, dynamic> toJson() => {'id': id, 'from': from, 'to': to, 'text': text, 'seen': seen};
  static Msg fromJson(Map<String, dynamic> j) => Msg(id: j['id'], from: j['from'], to: j['to'], text: j['text'], seen: j['seen'] ?? false);
}

class Req {
  String id, from, to;
  Req({required this.id, required this.from, required this.to});
}

class Store extends ChangeNotifier {
  List<Account> accounts = [];
  List<Msg> messages = [];
  List<Req> requests = [];
  List<String> friendPairs = [];
  String? currentId;
  bool en = false;
  String theme = 'device';
  bool soundOn = true;
  SharedPreferences? prefs;
  bool loaded = false;

  String t(String bn, String enTxt) => en ? enTxt : bn;

  Account? get me {
    for (final a in accounts) {
      if (a.id == currentId) return a;
    }
    return null;
  }

  bool areFriends(String a, String b) => friendPairs.contains(_pair(a, b));
  String _pair(String a, String b) => a.compareTo(b) < 0 ? '$a|$b' : '$b|$a';

  List<Account> friendsOf(String id) => accounts.where((a) => a.id != id && areFriends(id, a.id)).toList();

  int unseenFrom(String other) => messages.where((m) => m.to == currentId && m.from == other && !m.seen).length;

  int get totalUnseen => messages.where((m) => m.to == currentId && !m.seen).length;

  int get incomingRequestCount => currentId == null ? 0 : requests.where((r) => r.to == currentId).length;

  Future<void> load() async {
    prefs = await SharedPreferences.getInstance();
    final raw = prefs!.getString('adda_data');
    if (raw != null) {
      final j = jsonDecode(raw);
      accounts = (j['accounts'] as List).map((e) => Account.fromJson(e)).toList();
      messages = (j['messages'] as List).map((e) => Msg.fromJson(e)).toList();
      requests = (j['requests'] as List).map((e) => Req(id: e['id'], from: e['from'], to: e['to'])).toList();
      friendPairs = List<String>.from(j['friends'] ?? []);
      currentId = j['currentId'];
      en = j['en'] ?? false;
      theme = j['theme'] ?? 'device';
      soundOn = j['soundOn'] ?? true;
    }
    loaded = true;
    notifyListeners();
  }

  Future<void> save() async {
    if (prefs == null) return;
    await prefs!.setString('adda_data', jsonEncode({
      'accounts': accounts.map((a) => a.toJson()).toList(),
      'messages': messages.map((m) => m.toJson()).toList(),
      'requests': requests.map((r) => {'id': r.id, 'from': r.from, 'to': r.to}).toList(),
      'friends': friendPairs,
      'currentId': currentId,
      'en': en,
      'theme': theme,
      'soundOn': soundOn,
    }));
  }

  Future<void> createAccount(String name, String username, String bio) async {
    final clean = username.trim().toLowerCase().replaceAll(' ', '');
    if (name.trim().isEmpty || clean.isEmpty) return;
    if (accounts.any((a) => a.username == clean)) return;
    final a = Account(id: DateTime.now().millisecondsSinceEpoch.toString(), name: name.trim(), username: clean, bio: bio.trim(), online: true);
    accounts.add(a);
    currentId = a.id;
    notifyListeners();
    await save();
  }

  void enter(String id) {
    currentId = id;
    notifyListeners();
    save();
  }

  void logout() {
    currentId = null;
    notifyListeners();
    save();
  }

  void toggleLanguage() {
    en = !en;
    notifyListeners();
    save();
  }

  void cycleTheme() {
    theme = theme == 'light' ? 'dark' : theme == 'dark' ? 'device' : 'light';
    notifyListeners();
    save();
  }

  void toggleSound() {
    soundOn = !soundOn;
    notifyListeners();
    save();
  }

  void updateProfile(String name, String bio) {
    final m = me;
    if (m == null) return;
    if (name.trim().isNotEmpty) m.name = name.trim();
    m.bio = bio.trim();
    notifyListeners();
    save();
  }

  void sendRequest(String to) {
    final meId = currentId!;
    if (requests.any((r) => (r.from == meId && r.to == to) || (r.from == to && r.to == meId))) return;
    requests.add(Req(id: DateTime.now().millisecondsSinceEpoch.toString(), from: meId, to: to));
    notifyListeners();
    save();
  }

  void cancelRequest(String to) {
    requests.removeWhere((r) => r.from == currentId && r.to == to);
    notifyListeners();
    save();
  }

  void respond(String reqId, bool accept) {
    Req? r;
    for (final x in requests) {
      if (x.id == reqId) r = x;
    }
    if (r == null) return;
    requests.remove(r);
    if (accept) friendPairs.add(_pair(r.from, r.to));
    notifyListeners();
    save();
  }

  void unfriend(String other) {
    friendPairs.remove(_pair(currentId!, other));
    notifyListeners();
    save();
  }

  void sendMessage(String to, String text) {
    if (text.trim().isEmpty) return;
    messages.add(Msg(id: DateTime.now().millisecondsSinceEpoch.toString(), from: currentId!, to: to, text: text.trim()));
    notifyListeners();
    save();
  }

  void markSeen(String other) {
    var changed = false;
    for (final m in messages) {
      if (m.to == currentId && m.from == other && !m.seen) {
        m.seen = true;
        changed = true;
      }
    }
    if (changed) {
      notifyListeners();
      save();
    }
  }

  Future<void> deleteAccount(String id) async {
    accounts.removeWhere((a) => a.id == id);
    messages.removeWhere((m) => m.from == id || m.to == id);
    requests.removeWhere((r) => r.from == id || r.to == id);
    friendPairs.removeWhere((p) => p.contains(id));
    if (currentId == id) currentId = null;
    notifyListeners();
    await save();
  }
}

class AddaApp extends StatefulWidget {
  const AddaApp({super.key});
  @override
  State<AddaApp> createState() => _AddaAppState();
}

class _AddaAppState extends State<AddaApp> {
  final store = Store();
  @override
  void initState() {
    super.initState();
    store.load();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final dark = store.theme == 'dark' || (store.theme == 'device' && MediaQuery.platformBrightnessOf(context) == Brightness.dark);
        return MaterialApp(
          title: 'Adda',
          debugShowCheckedModeBanner: false,
          themeMode: dark ? ThemeMode.dark : ThemeMode.light,
          theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: green, brightness: Brightness.light), scaffoldBackgroundColor: const Color(0xFFF4F7F5)),
          darkTheme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: green, brightness: Brightness.dark), scaffoldBackgroundColor: const Color(0xFF101613)),
          home: !store.loaded ? const Scaffold(body: Center(child: CircularProgressIndicator())) : SplashGate(store: store),
        );
      },
    );
  }
}

class SplashGate extends StatefulWidget {
  final Store store;
  const SplashGate({super.key, required this.store});
  @override
  State<SplashGate> createState() => _SplashGateState();
}

class _SplashGateState extends State<SplashGate> {
  bool show = true;
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 2400), () {
      if (mounted) setState(() => show = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    if (show) {
      return Scaffold(
        body: Container(
          decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF0B6B4F), Color(0xFF12A070), Color(0xFF7ED957)])),
          child: const Center(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('a.', style: TextStyle(fontSize: 60, fontWeight: FontWeight.w900, color: Colors.white)),
                Text('আড্ডা', style: TextStyle(fontSize: 60, fontWeight: FontWeight.w900, color: Colors.white)),
                Text('.', style: TextStyle(fontSize: 60, fontWeight: FontWeight.w900, color: amber)),
              ],
            ),
          ),
        ),
      );
    }
    return widget.store.me == null ? AuthScreen(store: widget.store) : HomeScreen(store: widget.store);
  }
}

// ---------- shared widgets ----------

Widget avatar(String name, bool online, double size) {
  return Container(
    padding: EdgeInsets.all(online ? 3 : 0),
    decoration: BoxDecoration(
      shape: BoxShape.circle,
      gradient: online ? const LinearGradient(colors: [green, greenLight, yellow]) : null,
    ),
    child: Stack(
      children: [
        CircleAvatar(radius: size / 2, backgroundColor: green, child: Text(name.isEmpty ? '?' : name[0], style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
        if (online)
          Positioned(
            right: 0,
            bottom: 0,
            child: Container(width: 14, height: 14, decoration: BoxDecoration(color: const Color(0xFF2ECC71), shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2))),
          ),
      ],
    ),
  );
}

Widget wordmark(Store s, double size) {
  final word = s.en ? 'Adda' : 'আড্ডা';
  return Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      ShaderMask(
        shaderCallback: (b) => const LinearGradient(colors: [green, greenLight]).createShader(b),
        child: Text(word, style: TextStyle(fontSize: size, fontWeight: FontWeight.w900, color: Colors.white)),
      ),
      Text('.', style: TextStyle(fontSize: size, fontWeight: FontWeight.w900, color: amber)),
    ],
  );
}

Widget heroChip(String label) => Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(color: Colors.white.withOpacity(0.22), borderRadius: BorderRadius.circular(20)),
      child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
    );

Widget badgeIcon(BuildContext context, IconData icon, int count, VoidCallback onTap) {
  return Stack(
    clipBehavior: Clip.none,
    children: [
      IconButton(icon: Icon(icon), onPressed: onTap),
      if (count > 0)
        Positioned(
          right: 4,
          top: 4,
          child: Container(
            padding: const EdgeInsets.all(3),
            decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
            constraints: const BoxConstraints(minWidth: 17, minHeight: 17),
            child: Text('$count', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
          ),
        ),
    ],
  );
}

void showNote(BuildContext context, Store s, String title, String body) {
  showDialog(
    context: context,
    builder: (_) => AlertDialog(
      title: Text(title),
      content: Text(body),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text(s.t('ঠিক আছে', 'OK')))],
    ),
  );
}

// ---------- auth / account picker ----------

class AuthScreen extends StatefulWidget {
  final Store store;
  const AuthScreen({super.key, required this.store});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool creating = false;
  final nameC = TextEditingController();
  final userC = TextEditingController();
  final bioC = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final s = widget.store;
    return Scaffold(
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              IconButton(icon: const Icon(Icons.phone_android), onPressed: () {}),
              TextButton(onPressed: () => s.toggleLanguage(), child: Text(s.en ? 'বাং' : 'EN')),
            ],
          ),
          wordmark(s, 44),
          const SizedBox(height: 8),
          Text(s.t('সবার আড্ডায় স্বাগতম', "Welcome to everyone's Adda"), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: Text(s.t('অ্যাকাউন্ট বেছে নিন', 'Choose an account'), style: const TextStyle(fontWeight: FontWeight.bold))),
              if (s.accounts.isNotEmpty)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(color: const Color(0xFFE6F5EE), borderRadius: BorderRadius.circular(20)),
                  child: Text(s.en ? '${s.accounts.length} accounts' : '${s.accounts.length}টি অ্যাকাউন্ট', style: const TextStyle(color: green, fontWeight: FontWeight.bold, fontSize: 12)),
                ),
            ],
          ),
          const SizedBox(height: 8),
          for (final a in s.accounts)
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              child: ListTile(
                leading: avatar(a.name, true, 48),
                title: Text(a.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('@${a.username}${a.bio.isEmpty ? '' : ' · ${a.bio}'}'),
                    Text(a.online ? s.t('এখন অনলাইনে আছে', 'Online now') : s.t('অফলাইন', 'Offline'), style: const TextStyle(color: Colors.grey)),
                  ],
                ),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    FilledButton(onPressed: () => s.enter(a.id), child: Text(s.t('ঢুকুন', 'Enter'))),
                    IconButton(icon: const Icon(Icons.delete_outline, color: Colors.red), onPressed: () => s.deleteAccount(a.id)),
                  ],
                ),
              ),
            ),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: () => setState(() => creating = !creating),
            style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
            child: Text(s.t('নতুন অ্যাকাউন্ট তৈরি করুন', 'Create a new account')),
          ),
          if (creating) ...[
            const SizedBox(height: 12),
            TextField(controller: nameC, decoration: InputDecoration(labelText: s.t('নাম', 'Name'), border: const OutlineInputBorder())),
            const SizedBox(height: 8),
            TextField(controller: userC, decoration: InputDecoration(labelText: s.t('ইউজারনেম', 'Username'), border: const OutlineInputBorder())),
            const SizedBox(height: 8),
            TextField(controller: bioC, decoration: InputDecoration(labelText: s.t('বায়ো', 'Bio'), border: const OutlineInputBorder())),
            const SizedBox(height: 8),
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              child: ListTile(
                leading: avatar(nameC.text.isEmpty ? '?' : nameC.text, true, 48),
                title: Text(nameC.text.isEmpty ? s.t('তোমার নাম', 'Your name') : nameC.text, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('@${userC.text.isEmpty ? 'username' : userC.text}'),
              ),
            ),
            const SizedBox(height: 8),
            FilledButton(
              onPressed: () async {
                await s.createAccount(nameC.text, userC.text, bioC.text);
              },
              style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
              child: Text(s.t('তৈরি করুন', 'Create')),
            ),
          ],
        ],
      ),
    );
  }
}

// ---------- home with web-style header + 4 tabs ----------

class HomeScreen extends StatefulWidget {
  final Store store;
  const HomeScreen({super.key, required this.store});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;
  Account? chatWith;

  void cycleTheme(Store s) => s.cycleTheme();

  void openNotifications(Store s, Account me) {
    final incoming = s.requests.where((r) => r.to == me.id).toList();
    final unseen = s.messages.where((m) => m.to == me.id && !m.seen).toList();
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (_) => ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(s.t('নোটিফিকেশন', 'Notifications'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          if (incoming.isEmpty && unseen.isEmpty) Text(s.t('কোনো নতুন নোটিফিকেশন নেই', 'No new notifications')),
          for (final r in incoming)
            Builder(builder: (_) {
              Account? from;
              for (final a in s.accounts) {
                if (a.id == r.from) from = a;
              }
              if (from == null) return const SizedBox();
              final f = from;
              return ListTile(
                leading: avatar(f.name, f.online, 44),
                title: Text(s.en ? '${f.name} sent you a friend request' : '${f.name} তোমাকে ফ্রেন্ড রিকোয়েস্ট পাঠিয়েছে'),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextButton(onPressed: () {
                      s.respond(r.id, true);
                      Navigator.pop(context);
                    }, child: Text(s.t('গ্রহণ', 'Accept'))),
                    TextButton(onPressed: () {
                      s.respond(r.id, false);
                      Navigator.pop(context);
                    }, child: Text(s.t('বাদ', 'Reject'))),
                  ],
                ),
              );
            }),
          for (final m in unseen)
            Builder(builder: (_) {
              Account? from;
              for (final a in s.accounts) {
                if (a.id == m.from) from = a;
              }
              if (from == null) return const SizedBox();
              final f = from;
              return ListTile(
                leading: avatar(f.name, f.online, 44),
                title: Text(f.name),
                subtitle: Text(m.text, maxLines: 1),
                onTap: () {
                  Navigator.pop(context);
                  setState(() {
                    chatWith = f;
                  });
                },
              );
            }),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.store;
    final me = s.me!;
    if (chatWith != null) {
      return ChatScreen(store: s, me: me, friend: chatWith!, onBack: () => setState(() => chatWith = null));
    }
    Widget body;
    if (tab == 0) {
      body = MessagesTab(store: s, me: me, onChat: (a) => setState(() => chatWith = a));
    } else if (tab == 1) {
      body = FriendsTab(store: s, me: me, onChat: (a) => setState(() => chatWith = a), onFindPeople: () => setState(() => tab = 2));
    } else if (tab == 2) {
      body = PeopleTab(store: s, me: me, onChat: (a) => setState(() => chatWith = a));
    } else {
      body = ProfileTab(store: s, me: me);
    }
    final notifCount = s.totalUnseen + s.incomingRequestCount;
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            // Web-style header bar, on all tabs.
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 8, 0),
              child: Row(
                children: [
                  wordmark(s, 26),
                  const Spacer(),
                  TextButton(onPressed: () => s.toggleLanguage(), child: Text(s.en ? 'বাং' : 'EN')),
                  IconButton(
                    icon: Icon(s.theme == 'dark' ? Icons.dark_mode : s.theme == 'light' ? Icons.light_mode : Icons.phone_android),
                    onPressed: () => cycleTheme(s),
                  ),
                  IconButton(icon: const Icon(Icons.search), onPressed: () => setState(() => tab = 2)),
                  badgeIcon(context, Icons.notifications_outlined, notifCount, () => openNotifications(s, me)),
                  badgeIcon(context, Icons.chat_bubble_outline, s.totalUnseen, () => setState(() => tab = 0)),
                  IconButton(icon: Icon(s.soundOn ? Icons.volume_up : Icons.volume_off), onPressed: () => s.toggleSound()),
                  const SizedBox(width: 4),
                  InkWell(onTap: () => setState(() => tab = 3), child: avatar(me.name, true, 40)),
                ],
              ),
            ),
            Expanded(child: body),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        decoration: BoxDecoration(color: Theme.of(context).colorScheme.surface, borderRadius: BorderRadius.circular(28), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.12), blurRadius: 16, offset: const Offset(0, 4))]),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(28),
          child: BottomNavigationBar(
            type: BottomNavigationBarType.fixed,
            currentIndex: tab,
            onTap: (i) => setState(() => tab = i),
            selectedItemColor: green,
            items: [
              BottomNavigationBarItem(icon: const Icon(Icons.chat_bubble_outline), label: s.t('মেসেজ', 'Messages')),
              BottomNavigationBarItem(icon: const Icon(Icons.people_outline), label: s.t('বন্ধু', 'Friends')),
              BottomNavigationBarItem(icon: const Icon(Icons.search), label: s.t('মানুষ', 'People')),
              BottomNavigationBarItem(icon: const Icon(Icons.person_outline), label: s.t('প্রোফাইল', 'Profile')),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------- messages tab ----------

class MessagesTab extends StatelessWidget {
  final Store store;
  final Account me;
  final void Function(Account) onChat;
  const MessagesTab({super.key, required this.store, required this.me, required this.onChat});

  @override
  Widget build(BuildContext context) {
    final s = store;
    final friends = s.friendsOf(me.id);
    final strip = [...friends]..sort((a, b) => (b.online ? 1 : 0).compareTo(a.online ? 1 : 0));
    final chatPartners = friends.where((f) => s.messages.any((m) => (m.from == me.id && m.to == f.id) || (m.from == f.id && m.to == me.id))).toList();
    final unseenTotal = s.totalUnseen;
    final onlineCount = friends.where((f) => f.online).length;
    return ListView(
      children: [
        Container(
          margin: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: const LinearGradient(colors: [Color(0xFF0B6B4F), Color(0xFF12A070), Color(0xFF7ED957)])),
          child: Stack(
            children: [
              const Positioned(right: 0, bottom: 0, child: Text('আড্ডা', style: TextStyle(fontSize: 48, fontWeight: FontWeight.w900, color: Colors.white24))),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(child: Text(s.t('মেসেজ', 'Messages'), style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: Colors.white))),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(color: Colors.white.withOpacity(0.22), borderRadius: BorderRadius.circular(20)),
                        child: Text(s.en ? '${chatPartners.length} chats' : '${chatPartners.length}টি আড্ডা', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                      ),
                    ],
                  ),
                  Text(s.t('বন্ধুদের সাথে আড্ডা জমে উঠুক', 'Chat away with your friends'), style: const TextStyle(color: Colors.white)),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    children: [
                      heroChip(s.en ? '$onlineCount online' : '$onlineCount জন অনলাইন'),
                      heroChip(s.en ? '$unseenTotal unseen' : '$unseenTotal দেখা হয়নি'),
                      heroChip(s.en ? '${friends.length} friends' : '${friends.length} বন্ধু'),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
        if (strip.isNotEmpty)
          SizedBox(
            height: 76,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: strip.map((f) {
                final unread = s.unseenFrom(f.id);
                return Padding(
                  padding: const EdgeInsets.only(right: 14),
                  child: InkWell(
                    onTap: () => onChat(f),
                    child: Column(
                      children: [
                        Stack(
                          clipBehavior: Clip.none,
                          children: [
                            avatar(f.name, f.online, 56),
                            if (unread > 0)
                              Positioned(
                                right: -2,
                                top: -2,
                                child: Container(
                                  padding: const EdgeInsets.all(3),
                                  decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                                  constraints: const BoxConstraints(minWidth: 18, minHeight: 18),
                                  child: Text('$unread', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
                                ),
                              ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text(f.name.split(' ').first, style: const TextStyle(fontSize: 12)),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        const Divider(),
        for (final f in friends)
          Builder(builder: (_) {
            final msgs = s.messages.where((m) => (m.from == me.id && m.to == f.id) || (m.from == f.id && m.to == me.id)).toList();
            final last = msgs.isEmpty ? null : msgs.last;
            final unread = s.unseenFrom(f.id);
            return Container(
              color: unread > 0 ? const Color(0xFFE6F5EE) : null,
              child: ListTile(
                leading: avatar(f.name, f.online, 48),
                title: Text(f.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text(last == null ? s.t('চ্যাট শুরু করুন', 'Start chatting') : last.text, maxLines: 1),
                trailing: unread > 0
                    ? CircleAvatar(radius: 11, backgroundColor: Colors.red, child: Text('$unread', style: const TextStyle(color: Colors.white, fontSize: 12)))
                    : null,
                onTap: () => onChat(f),
              ),
            );
          }),
      ],
    );
  }
}

// ---------- friends tab ----------

class FriendsTab extends StatefulWidget {
  final Store store;
  final Account me;
  final void Function(Account) onChat;
  final VoidCallback onFindPeople;
  const FriendsTab({super.key, required this.store, required this.me, required this.onChat, required this.onFindPeople});
  @override
  State<FriendsTab> createState() => _FriendsTabState();
}

class _FriendsTabState extends State<FriendsTab> {
  String q = '';
  @override
  Widget build(BuildContext context) {
    final s = widget.store;
    final me = widget.me;
    final friends = s.friendsOf(me.id).where((a) => q.isEmpty || a.name.toLowerCase().contains(q.toLowerCase()) || a.username.toLowerCase().contains(q.toLowerCase())).toList();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          children: [
            Expanded(child: Text(s.en ? 'Friends (${s.friendsOf(me.id).length})' : 'বন্ধুরা (${s.friendsOf(me.id).length})', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
            FilledButton.icon(onPressed: widget.onFindPeople, icon: const Icon(Icons.person_add_alt_1), label: Text(s.t('মানুষ খুঁজুন', 'Find people')), style: FilledButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)))),
          ],
        ),
        const SizedBox(height: 12),
        TextField(
          onChanged: (v) => setState(() => q = v),
          decoration: InputDecoration(hintText: s.t('বন্ধু খুঁজুন...', 'Search friends...'), prefixIcon: const Icon(Icons.search), border: OutlineInputBorder(borderRadius: BorderRadius.circular(20))),
        ),
        const SizedBox(height: 12),
        for (final f in friends)
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            child: ListTile(
              leading: avatar(f.name, f.online, 48),
              title: Text(f.name, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(f.bio.isEmpty ? '@${f.username}' : f.bio),
              trailing: IconButton(icon: const Icon(Icons.chat_bubble_outline, color: green), onPressed: () => widget.onChat(f)),
            ),
          ),
        if (friends.isEmpty) Text(s.t('এখনো কোনো বন্ধু নেই — মানুষ ট্যাব থেকে রিকোয়েস্ট পাঠাও।', 'No friends yet — send a request from the People tab.')),
      ],
    );
  }
}

// ---------- people tab with detail panel ----------

class PeopleTab extends StatefulWidget {
  final Store store;
  final Account me;
  final void Function(Account) onChat;
  const PeopleTab({super.key, required this.store, required this.me, required this.onChat});
  @override
  State<PeopleTab> createState() => _PeopleTabState();
}

class _PeopleTabState extends State<PeopleTab> {
  String q = '';
  String? selectedId;

  @override
  Widget build(BuildContext context) {
    final s = widget.store;
    final me = widget.me;
    final incoming = s.requests.where((r) => r.to == me.id).toList();
    final others = s.accounts.where((a) => a.id != me.id && (q.isEmpty || a.name.toLowerCase().contains(q.toLowerCase()) || a.username.toLowerCase().contains(q.toLowerCase()))).toList();
    Account? selected;
    for (final a in others) {
      if (a.id == selectedId) selected = a;
    }
    // Also allow selecting someone filtered out by search? Keep selection only from visible list.
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(s.en ? 'Find people (${others.length})' : 'মানুষ খুঁজুন (${others.length} জন)', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        TextField(
          onChanged: (v) => setState(() => q = v),
          decoration: InputDecoration(hintText: s.t('নাম বা @ইউজারনেম দিয়ে খুঁজুন...', 'Search by name or @username...'), prefixIcon: const Icon(Icons.search), border: OutlineInputBorder(borderRadius: BorderRadius.circular(20))),
        ),
        if (incoming.isNotEmpty) ...[
          const SizedBox(height: 12),
          Text(s.t('ফ্রেন্ড রিকোয়েস্ট এসেছে', 'Friend requests'), style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
        for (final r in incoming)
          Builder(builder: (_) {
            Account? from;
            for (final a in s.accounts) {
              if (a.id == r.from) from = a;
            }
            if (from == null) return const SizedBox();
            final f2 = from;
            return ListTile(
              leading: avatar(f2.name, f2.online, 48),
              title: Text(f2.name),
              subtitle: Text('@${f2.username}'),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextButton(onPressed: () => s.respond(r.id, true), child: Text(s.t('গ্রহণ', 'Accept'))),
                  TextButton(onPressed: () => s.respond(r.id, false), child: Text(s.t('বাদ', 'Reject'))),
                ],
              ),
            );
          }),
        const SizedBox(height: 12),
        for (final a in others)
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            color: selectedId == a.id ? const Color(0xFFE6F5EE) : null,
            child: ListTile(
              leading: avatar(a.name, a.online, 48),
              title: Text(a.name, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(s.areFriends(me.id, a.id) ? s.t('বন্ধু', 'Friend') : '@${a.username}'),
              trailing: const Icon(Icons.chat_bubble_outline, color: green),
              onTap: () => setState(() => selectedId = a.id),
            ),
          ),
        if (selected != null) ...[
          const SizedBox(height: 16),
          _personDetail(context, s, me, selected),
        ],
      ],
    );
  }

  Widget _personDetail(BuildContext context, Store s, Account me, Account p) {
    final isFriend = s.areFriends(me.id, p.id);
    Req? incoming;
    for (final r in s.requests) {
      if (r.from == p.id && r.to == me.id) incoming = r;
    }
    final outgoing = s.requests.any((r) => r.from == me.id && r.to == p.id);
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                avatar(p.name, p.online, 56),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(p.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      Text('@${p.username}'),
                      Text(p.online ? s.t('এখন অনলাইনে আছে', 'Online now') : s.t('অফলাইন', 'Offline'), style: const TextStyle(color: green)),
                    ],
                  ),
                ),
              ],
            ),
            if (p.bio.isNotEmpty) ...[const SizedBox(height: 8), Text(p.bio)],
            const SizedBox(height: 12),
            if (isFriend)
              FilledButton.icon(
                onPressed: () => widget.onChat(p),
                icon: const Icon(Icons.chat_bubble_outline),
                label: Text(s.t('মেসেজ করুন', 'Message')),
                style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(48), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
              )
            else if (incoming != null)
              Row(
                children: [
                  Expanded(child: FilledButton(onPressed: () => s.respond(incoming!.id, true), child: Text(s.t('গ্রহণ', 'Accept')))),
                  const SizedBox(width: 8),
                  Expanded(child: OutlinedButton(onPressed: () => s.respond(incoming!.id, false), child: Text(s.t('বাদ', 'Reject')))),
                ],
              )
            else if (outgoing)
              Row(
                children: [
                  Expanded(child: OutlinedButton(onPressed: () => s.cancelRequest(p.id), child: Text(s.t('রিকোয়েস্ট বাতিল', 'Cancel request')))),
                  const SizedBox(width: 8),
                  Expanded(child: Text(s.t('পাঠানো হয়েছে', 'Sent'), textAlign: TextAlign.center, style: const TextStyle(color: Colors.grey))),
                ],
              )
            else
              FilledButton(
                onPressed: () => s.sendRequest(p.id),
                style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(48), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
                child: Text(s.t('ফ্রেন্ড রিকোয়েস্ট পাঠান', 'Send friend request')),
              ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: isFriend ? () => Navigator.push(context, MaterialPageRoute(builder: (_) => CallScreen(store: s, me: me, friend: p, kind: 'audio'))) : null,
                    icon: const Icon(Icons.call),
                    label: Text(s.t('কল', 'Call')),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: isFriend ? () => Navigator.push(context, MaterialPageRoute(builder: (_) => CallScreen(store: s, me: me, friend: p, kind: 'video'))) : null,
                    icon: const Icon(Icons.videocam),
                    label: Text(s.t('ভিডিও', 'Video')),
                  ),
                ),
              ],
            ),
            if (isFriend) ...[
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: () => s.unfriend(p.id),
                  style: OutlinedButton.styleFrom(foregroundColor: Colors.red),
                  child: Text(s.t('আনফ্রেন্ড', 'Unfriend')),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

// ---------- profile tab: menu-based, web style ----------

class ProfileTab extends StatelessWidget {
  final Store store;
  final Account me;
  const ProfileTab({super.key, required this.store, required this.me});

  Future<void> _deleteFlow(BuildContext context, Store s, Account m) async {
    final ctrl = TextEditingController();
    var typedOk = false;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: Text(s.t('অ্যাকাউন্ট মুছুন?', 'Delete account?')),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(s.t('এই অ্যাকাউন্টের সব মেসেজ, বন্ধুত্ব ও ছবি স্থায়ীভাবে মুছে যাবে। নিশ্চিত করতে @ইউজারনেমটি হুবহু লিখুন:', 'All messages, friendships and photos for this account will be permanently deleted. Type the exact @username to confirm:')),
              const SizedBox(height: 12),
              TextField(
                controller: ctrl,
                decoration: InputDecoration(hintText: '@${m.username}', border: const OutlineInputBorder()),
                onChanged: (v) => setD(() => typedOk = v.trim() == '@${m.username}' || v.trim() == m.username),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(s.t('বাতিল', 'Cancel'))),
            FilledButton(onPressed: typedOk ? () => Navigator.pop(ctx, true) : null, child: Text(s.t('মুছুন', 'Delete'))),
          ],
        ),
      ),
    );
    if (ok == true) s.deleteAccount(m.id);
  }

  Future<void> _editProfile(BuildContext context, Store s, Account m) async {
    final nameC = TextEditingController(text: m.name);
    final bioC = TextEditingController(text: m.bio);
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(s.t('প্রোফাইল সম্পাদনা করুন', 'Edit profile')),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: nameC, decoration: InputDecoration(labelText: s.t('নাম', 'Name'), border: const OutlineInputBorder())),
            const SizedBox(height: 8),
            TextField(controller: bioC, decoration: InputDecoration(labelText: s.t('বায়ো', 'Bio'), border: const OutlineInputBorder())),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text(s.t('বাতিল', 'Cancel'))),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(s.t('সংরক্ষণ', 'Save'))),
        ],
      ),
    );
    if (ok == true) s.updateProfile(nameC.text, bioC.text);
  }

  Widget _sectionTitle(String label, {bool red = false}) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 16, 4, 8),
        child: Text(label, style: TextStyle(fontWeight: FontWeight.bold, color: red ? Colors.red : null)),
      );

  Widget _menuCard(List<Widget> rows) => Card(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)), child: Column(children: rows));

  @override
  Widget build(BuildContext context) {
    final s = store;
    final friends = s.friendsOf(me.id).length;
    final chats = s.messages.where((m) => m.from == me.id || m.to == me.id).map((m) => m.from == me.id ? m.to : m.from).toSet().length;
    final reqs = s.incomingRequestCount;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
      children: [
        // Cover band + overlapping avatar, web style.
        Stack(
          clipBehavior: Clip.none,
          children: [
            Container(
              height: 120,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: const LinearGradient(colors: [Color(0xFFB03050), Color(0xFF7A3B2E), Color(0xFF5B3A1E)])),
            ),
            Positioned(
              right: 12,
              bottom: 12,
              child: FilledButton.icon(
                onPressed: () => showNote(context, s, s.t('কভার ছবি', 'Cover photo'), s.t('এই বিল্ডে ছবি বাছাই করা যায় না।', 'Photo picking is not available in this build.')),
                icon: const Icon(Icons.camera_alt, size: 16),
                label: Text(s.t('কভার ছবি', 'Cover photo')),
                style: FilledButton.styleFrom(backgroundColor: Colors.black54),
              ),
            ),
            Positioned(
              left: 16,
              bottom: -32,
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  avatar(me.name, true, 88),
                  Positioned(
                    right: -2,
                    bottom: -2,
                    child: InkWell(
                      onTap: () => showNote(context, s, s.t('প্রোফাইল ছবি', 'Profile photo'), s.t('এই বিল্ডে ছবি বাছাই করা যায় না।', 'Photo picking is not available in this build.')),
                      child: Container(padding: const EdgeInsets.all(6), decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle, boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 6)]), child: const Icon(Icons.camera_alt, size: 16)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 44),
        Row(
          children: [
            Expanded(child: Text(me.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(color: const Color(0xFFE6F5EE), borderRadius: BorderRadius.circular(20)),
              child: Row(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.verified, size: 14, color: green), const SizedBox(width: 4), Text('@${me.username}', style: const TextStyle(color: green, fontWeight: FontWeight.bold))]),
            ),
          ],
        ),
        Text(me.online ? s.t('এখন অনলাইনে আছে', 'Online now') : s.t('অফলাইন', 'Offline'), style: const TextStyle(color: green)),
        if (me.bio.isNotEmpty) ...[const SizedBox(height: 4), Text(me.bio)],
        const SizedBox(height: 4),
        Text(s.en ? '$friends friends · $chats chats · $reqs requests' : '$friends বন্ধু · $chats চ্যাট · $reqs রিকোয়েস্ট'),
        _sectionTitle(s.t('প্রোফাইল', 'Profile')),
        _menuCard([
          ListTile(leading: const Icon(Icons.edit), title: Text(s.t('প্রোফাইল সম্পাদনা করুন', 'Edit profile')), subtitle: Text(s.t('নাম, বায়ো ও তথ্য বদলান', 'Change name, bio and info')), trailing: const Icon(Icons.chevron_right), onTap: () => _editProfile(context, s, me)),
          ListTile(leading: const Icon(Icons.info_outline), title: Text(s.t('আমার তথ্য', 'My info')), subtitle: Text(s.t('বায়ো, ঠিকানা, কাজ ও যোগ দেওয়ার তারিখ', 'Bio, address, work and joining date')), trailing: const Icon(Icons.chevron_right), onTap: () => showDialog(context: context, builder: (_) => AlertDialog(title: Text(me.name), content: Text('@${me.username}\n${me.bio.isEmpty ? s.t('কোনো বায়ো নেই', 'No bio yet') : me.bio}'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text(s.t('ঠিক আছে', 'OK')))]))),
          ListTile(leading: const Icon(Icons.camera_alt), title: Text(s.t('প্রোফাইল ছবি', 'Profile photo')), subtitle: Text(s.t('ছবি বদলান বা নতুন দিন', 'Change or add a photo')), trailing: const Icon(Icons.chevron_right), onTap: () => showNote(context, s, s.t('প্রোফাইল ছবি', 'Profile photo'), s.t('এই বিল্ডে ছবি বাছাই করা যায় না।', 'Photo picking is not available in this build.'))),
          ListTile(leading: const Icon(Icons.image), title: Text(s.t('কভার ছবি', 'Cover photo')), subtitle: Text(s.t('ছবি বদলান বা নতুন দিন', 'Change or add a photo')), trailing: const Icon(Icons.chevron_right), onTap: () => showNote(context, s, s.t('কভার ছবি', 'Cover photo'), s.t('এই বিল্ডে ছবি বাছাই করা যায় না।', 'Photo picking is not available in this build.'))),
        ]),
        _sectionTitle(s.t('সেটিংস', 'Settings')),
        _menuCard([
          ListTile(
            leading: const Icon(Icons.wb_sunny),
            title: Text(s.t('থিম', 'Theme')),
            subtitle: Text(s.theme == 'light' ? 'Light' : s.theme == 'dark' ? 'Dark' : s.t('ডিভাইস', 'Device')),
            trailing: Text(s.theme == 'light' ? 'Light' : s.theme == 'dark' ? 'Dark' : s.t('ডিভাইস', 'Device')),
            onTap: () => s.cycleTheme(),
          ),
          ListTile(
            leading: const Icon(Icons.language),
            title: Text(s.t('ভাষা', 'Language')),
            subtitle: Text(s.en ? 'English' : 'বাংলা'),
            trailing: Text(s.en ? 'English' : 'বাংলা'),
            onTap: () => s.toggleLanguage(),
          ),
        ]),
        _sectionTitle(s.t('অ্যাকাউন্ট', 'Account')),
        _menuCard([
          ListTile(title: Text(s.t('অ্যাকাউন্ট বদলান', 'Switch account')), trailing: const Icon(Icons.chevron_right), onTap: () => s.logout()),
          ListTile(title: Text(s.t('লগআউট', 'Logout')), trailing: const Icon(Icons.chevron_right), onTap: () => s.logout()),
        ]),
        _sectionTitle(s.t('বিপজ্জনক এলাকা', 'Danger zone'), red: true),
        _menuCard([
          ListTile(title: Text(s.t('অ্যাকাউন্ট মুছুন', 'Delete account'), style: const TextStyle(color: Colors.red)), subtitle: Text(s.t('স্থায়ীভাবে মুছে যাবে', 'Will be deleted permanently')), trailing: const Icon(Icons.chevron_right), onTap: () => _deleteFlow(context, s, me)),
        ]),
      ],
    );
  }
}

// ---------- chat ----------

class ChatScreen extends StatefulWidget {
  final Store store;
  final Account me;
  final Account friend;
  final VoidCallback onBack;
  const ChatScreen({super.key, required this.store, required this.me, required this.friend, required this.onBack});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final textC = TextEditingController();
  @override
  void initState() {
    super.initState();
    widget.store.markSeen(widget.friend.id);
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.store;
    final me = widget.me;
    final f = widget.friend;
    final msgs = s.messages.where((m) => (m.from == me.id && m.to == f.id) || (m.from == f.id && m.to == me.id)).toList();
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(icon: const Icon(Icons.arrow_back), onPressed: widget.onBack),
        title: Row(
          children: [
            avatar(f.name, f.online, 40),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(f.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text(f.online ? s.t('এখন অনলাইনে আছে', 'Online now') : s.t('অফলাইন', 'Offline'), style: const TextStyle(fontSize: 12, color: green)),
                ],
              ),
            ),
          ],
        ),
        actions: [
          IconButton(icon: const Icon(Icons.call), onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => CallScreen(store: s, me: me, friend: f, kind: 'audio')));
          }),
          IconButton(icon: const Icon(Icons.videocam), onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => CallScreen(store: s, me: me, friend: f, kind: 'video')));
          }),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(12),
              children: msgs.map((m) {
                final mine = m.from == me.id;
                return Align(
                  alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 3),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(26),
                      gradient: mine ? const LinearGradient(colors: [green, greenLight]) : null,
                      color: mine ? null : Theme.of(context).colorScheme.surfaceContainerHighest,
                    ),
                    child: Text(m.text, style: TextStyle(color: mine ? Colors.white : null)),
                  ),
                );
              }).toList(),
            ),
          ),
          Container(
            margin: const EdgeInsets.all(12),
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(color: Theme.of(context).colorScheme.surface, borderRadius: BorderRadius.circular(28), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 12)]),
            child: Row(
              children: [
                Expanded(child: TextField(controller: textC, decoration: InputDecoration(hintText: s.t('মেসেজ লিখুন', 'Write a message'), border: InputBorder.none, contentPadding: const EdgeInsets.symmetric(horizontal: 12)))),
                FilledButton(
                  onPressed: () {
                    s.sendMessage(f.id, textC.text);
                    textC.clear();
                  },
                  child: Text(s.t('পাঠান', 'Send')),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class CallScreen extends StatefulWidget {
  final Store store;
  final Account me;
  final Account friend;
  final String kind;
  const CallScreen({super.key, required this.store, required this.me, required this.friend, required this.kind});
  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  int sec = 0;
  bool muted = false;
  @override
  void initState() {
    super.initState();
    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 1));
      if (!mounted) return false;
      setState(() => sec++);
      return true;
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.store;
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            avatar(widget.friend.name, true, 96),
            const SizedBox(height: 16),
            Text(widget.friend.name, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            Text(widget.kind == 'video' ? s.t('ভিডিও কল', 'Video call') : s.t('ভয়েস কল', 'Voice call')),
            Text('${(sec ~/ 60).toString().padLeft(2, '0')}:${(sec % 60).toString().padLeft(2, '0')}', style: const TextStyle(fontSize: 20)),
            const SizedBox(height: 12),
            Padding(padding: const EdgeInsets.all(16), child: Text(s.t('টেস্ট সিস্টেম: দুই পাশে অ্যাপ খোলা থাকলে কল সংযোগ হবে। আসল দুই ডিভাইসের কল পেতে হোস্টেড সার্ভার লাগবে।', 'Test system: both sides must have the app open. A hosted server is needed for real two-device calls.'), textAlign: TextAlign.center)),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton.filled(onPressed: () => setState(() => muted = !muted), icon: Icon(muted ? Icons.mic_off : Icons.mic)),
                const SizedBox(width: 12),
                IconButton.filled(onPressed: () => Navigator.pop(context), style: IconButton.styleFrom(backgroundColor: Colors.red), icon: const Icon(Icons.call_end, color: Colors.white)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

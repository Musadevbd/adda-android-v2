import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Talky master-clone design system for Adda (layout/colours inspired by the Talky UI kit; Adda branding kept).
const blue = Color(0xFF2B6BFF);
const blueDark = Color(0xFF1D4ED8);
const blueLight = Color(0xFF3B82F6);
const appBg = Color(0xFFEDF2F9);
const softCard = Color(0xFFE4EDFB);
const slate = Color(0xFF848BAD);
const slateLight = Color(0xFFA0AABD);
const ink = Color(0xFF0F101A);
const yellow = Color(0xFFFFC93C);
const amber = Color(0xFFF5B301);

String bnNum(int n) {
  const en = '0123456789';
  const bn = '০১২৩৪৫৬৭৮৯';
  var s = '$n';
  for (var i = 0; i < 10; i++) {
    s = s.replaceAll(en[i], bn[i]);
  }
  return s;
}

class Account {
  String id, name, username, bio, photo, cover;
  bool online;
  int lastSeen;
  Account({required this.id, required this.name, required this.username, this.bio = '', this.online = false, this.lastSeen = 0, this.photo = '', this.cover = ''});
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'username': username, 'bio': bio, 'online': online, 'lastSeen': lastSeen, 'photo': photo, 'cover': cover};
  static Account fromJson(Map<String, dynamic> j) => Account(id: j['id'] ?? '', name: j['name'] ?? '', username: j['username'] ?? '', bio: j['bio'] ?? '', online: j['online'] ?? false, lastSeen: j['lastSeen'] ?? 0, photo: j['photo'] ?? '', cover: j['cover'] ?? '');
}

class Msg {
  String id, from, to, text, attachKind, attachName, attachData, reaction;
  bool seen;
  int createdAt;
  int durationSec;
  Msg({required this.id, required this.from, required this.to, required this.text, this.seen = false, this.createdAt = 0, this.attachKind = '', this.attachName = '', this.attachData = '', this.reaction = '', this.durationSec = 0});
  Map<String, dynamic> toJson() => {'id': id, 'from': from, 'to': to, 'text': text, 'seen': seen, 'createdAt': createdAt, 'attachKind': attachKind, 'attachName': attachName, 'attachData': attachData, 'reaction': reaction, 'durationSec': durationSec};
  static Msg fromJson(Map<String, dynamic> j) => Msg(id: j['id'] ?? '', from: j['from'] ?? '', to: j['to'] ?? '', text: j['text'] ?? '', seen: j['seen'] ?? false, createdAt: j['createdAt'] ?? 0, attachKind: j['attachKind'] ?? '', attachName: j['attachName'] ?? '', attachData: j['attachData'] ?? '', reaction: j['reaction'] ?? '', durationSec: j['durationSec'] ?? 0);
}

class Req {
  String id, from, to;
  Req({required this.id, required this.from, required this.to});
}

class Store extends ChangeNotifier {
  List<Account> accounts = [];
  List<Msg> messages = [];
  List<Req> requests = [];
  List<String> friendPairs = [];
  String? currentId;
  bool en = false;
  String theme = 'device';
  bool soundOn = true;
  bool justCreated = false;
  bool loaded = false;
  SharedPreferences? prefs;

  String t(String bn, String enTxt) => en ? enTxt : bn;
  Account? get me {
    for (final a in accounts) {
      if (a.id == currentId) return a;
    }
    return null;
  }

  bool areFriends(String a, String b) => friendPairs.contains(_pair(a, b));
  String _pair(String a, String b) => a.compareTo(b) < 0 ? '$a|$b' : '$b|$a';
  List<Account> friendsOf(String id) => accounts.where((a) => a.id != id && areFriends(id, a.id)).toList();
  int unseenFrom(String other) => messages.where((m) => m.to == currentId && m.from == other && !m.seen).length;
  int get totalUnseen => messages.where((m) => m.to == currentId && !m.seen).length;
  int get incomingRequestCount => currentId == null ? 0 : requests.where((r) => r.to == currentId).length;

  String relTime(int ms) {
    if (ms <= 0) return '';
    final diff = DateTime.now().difference(DateTime.fromMillisecondsSinceEpoch(ms));
    if (diff.inMinutes < 1) return t('এইমাত্র', 'just now');
    if (diff.inMinutes < 60) return en ? '${diff.inMinutes} min ago' : '${bnNum(diff.inMinutes)} মিনিট আগে';
    if (diff.inHours < 24) return en ? '${diff.inHours} hours ago' : '${bnNum(diff.inHours)} ঘণ্টা আগে';
    if (diff.inDays < 7) return en ? '${diff.inDays} days ago' : '${bnNum(diff.inDays)} দিন আগে';
    final d = DateTime.fromMillisecondsSinceEpoch(ms);
    return '${bnNum(d.day)}/${bnNum(d.month)}/${bnNum(d.year)}';
  }

  Future<void> load() async {
    prefs = await SharedPreferences.getInstance();
    final raw = prefs!.getString('adda_data');
    if (raw != null) {
      try {
        final j = jsonDecode(raw);
        accounts = (j['accounts'] as List).map((e) => Account.fromJson(e)).toList();
        messages = (j['messages'] as List).map((e) => Msg.fromJson(e)).toList();
        requests = (j['requests'] as List).map((e) => Req(id: e['id'], from: e['from'], to: e['to'])).toList();
        friendPairs = List<String>.from(j['friends'] ?? []);
        currentId = j['currentId'];
        en = j['en'] ?? false;
        theme = j['theme'] ?? 'device';
        soundOn = j['soundOn'] ?? true;
      } catch (_) {}
    }
    loaded = true;
    notifyListeners();
  }

  Future<void> save() async {
    if (prefs == null) return;
    await prefs!.setString('adda_data', jsonEncode({'accounts': accounts.map((a) => a.toJson()).toList(), 'messages': messages.map((m) => m.toJson()).toList(), 'requests': requests.map((r) => {'id': r.id, 'from': r.from, 'to': r.to}).toList(), 'friends': friendPairs, 'currentId': currentId, 'en': en, 'theme': theme, 'soundOn': soundOn}));
  }

  Future<void> createAccount(String name, String username, String bio) async {
    final clean = username.trim().toLowerCase().replaceAll(' ', '');
    if (name.trim().isEmpty || clean.isEmpty) return;
    if (accounts.any((a) => a.username == clean)) return;
    final now = DateTime.now().millisecondsSinceEpoch;
    final a = Account(id: now.toString(), name: name.trim(), username: clean, bio: bio.trim(), online: true, lastSeen: now);
    accounts.add(a);
    currentId = a.id;
    justCreated = true;
    notifyListeners();
    await save();
  }

  void enter(String id) {
    final a = accounts.firstWhere((x) => x.id == id, orElse: () => me!);
    a.online = true;
    a.lastSeen = DateTime.now().millisecondsSinceEpoch;
    currentId = id;
    justCreated = false;
    notifyListeners();
    save();
  }

  void logout() {
    currentId = null;
    justCreated = false;
    notifyListeners();
    save();
  }

  void toggleLanguage() {
    en = !en;
    notifyListeners();
    save();
  }

  void cycleTheme() {
    theme = theme == 'light' ? 'dark' : theme == 'dark' ? 'device' : 'light';
    notifyListeners();
    save();
  }

  void toggleOnline() {
    final m = me;
    if (m == null) return;
    m.online = !m.online;
    m.lastSeen = DateTime.now().millisecondsSinceEpoch;
    notifyListeners();
    save();
  }

  void toggleSound() {
    soundOn = !soundOn;
    notifyListeners();
    save();
  }

  void clearCelebration() {
    justCreated = false;
    notifyListeners();
  }

  void updateProfile(String name, String bio) {
    final m = me;
    if (m == null) return;
    if (name.trim().isNotEmpty) m.name = name.trim();
    m.bio = bio.trim();
    notifyListeners();
    save();
  }

  void setPhoto(bool cover, String b64) {
    final m = me;
    if (m == null) return;
    if (cover) {
      m.cover = b64;
    } else {
      m.photo = b64;
    }
    notifyListeners();
    save();
  }

  void sendRequest(String to) {
    final meId = currentId!;
    if (requests.any((r) => (r.from == meId && r.to == to) || (r.from == to && r.to == meId))) return;
    requests.add(Req(id: DateTime.now().millisecondsSinceEpoch.toString(), from: meId, to: to));
    notifyListeners();
    save();
  }

  void cancelRequest(String to) {
    requests.removeWhere((r) => r.from == currentId && r.to == to);
    notifyListeners();
    save();
  }

  void respond(String reqId, bool accept) {
    Req? r;
    for (final x in requests) {
      if (x.id == reqId) r = x;
    }
    if (r == null) return;
    requests.remove(r);
    if (accept) friendPairs.add(_pair(r.from, r.to));
    notifyListeners();
    save();
  }

  void unfriend(String other) {
    friendPairs.remove(_pair(currentId!, other));
    notifyListeners();
    save();
  }

  String? incomingCallFrom;
  void sendVoice(String to, int seconds) {
    messages.add(Msg(id: DateTime.now().millisecondsSinceEpoch.toString(), from: currentId!, to: to, text: '', createdAt: DateTime.now().millisecondsSinceEpoch, attachKind: 'voice', durationSec: seconds));
    notifyListeners();
    save();
  }

  void cycleReaction(String msgId) {
    const options = ['👏', '😉', '❤️', ''];
    for (final m in messages) {
      if (m.id == msgId) {
        final idx = options.indexOf(m.reaction);
        m.reaction = options[(idx + 1) % options.length];
      }
    }
    notifyListeners();
    save();
  }

  void sendMessage(String to, String text, {String kind = '', String name = '', String data = ''}) {
    if (text.trim().isEmpty && kind.isEmpty) return;
    messages.add(Msg(id: DateTime.now().millisecondsSinceEpoch.toString(), from: currentId!, to: to, text: text.trim(), createdAt: DateTime.now().millisecondsSinceEpoch, attachKind: kind, attachName: name, attachData: data));
    notifyListeners();
    save();
  }

  void markSeen(String other) {
    var changed = false;
    for (final m in messages) {
      if (m.to == currentId && m.from == other && !m.seen) {
        m.seen = true;
        changed = true;
      }
    }
    if (changed) {
      notifyListeners();
      save();
    }
  }

  void markAllSeen() {
    var changed = false;
    for (final m in messages) {
      if (m.to == currentId && !m.seen) {
        m.seen = true;
        changed = true;
      }
    }
    if (changed) {
      notifyListeners();
      save();
    }
  }

  Future<void> deleteAccount(String id) async {
    accounts.removeWhere((a) => a.id == id);
    messages.removeWhere((m) => m.from == id || m.to == id);
    requests.removeWhere((r) => r.from == id || r.to == id);
    friendPairs.removeWhere((p) => p.contains(id));
    if (currentId == id) currentId = null;
    notifyListeners();
    await save();
  }
}

void main() => runApp(const AddaApp());

class AddaApp extends StatefulWidget {
  const AddaApp({super.key});
  @override
  State<AddaApp> createState() => _AddaAppState();
}

class _AddaAppState extends State<AddaApp> {
  final store = Store();
  @override
  void initState() {
    super.initState();
    store.load();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final dark = store.theme == 'dark' || (store.theme == 'device' && MediaQuery.platformBrightnessOf(context) == Brightness.dark);
        final base = ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: blue, brightness: dark ? Brightness.dark : Brightness.light), scaffoldBackgroundColor: dark ? const Color(0xFF0F101A) : appBg);
        return MaterialApp(
          themeAnimationDuration: const Duration(milliseconds: 400),
          themeAnimationCurve: Curves.easeInOut,
          title: 'Adda',
          debugShowCheckedModeBanner: false,
          themeMode: dark ? ThemeMode.dark : ThemeMode.light,
          theme: base.copyWith(textTheme: GoogleFonts.hindSiliguriTextTheme(base.textTheme).copyWith(titleLarge: GoogleFonts.poppins(fontWeight: FontWeight.w900, fontSize: 22, color: ink).copyWith(fontFamilyFallback: const ['Hind Siliguri']), headlineSmall: GoogleFonts.poppins(fontWeight: FontWeight.w900, fontSize: 20, color: ink).copyWith(fontFamilyFallback: const ['Hind Siliguri']), bodyLarge: const TextStyle(fontSize: 16), bodyMedium: const TextStyle(fontSize: 15), labelLarge: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)), cardTheme: CardTheme(elevation: 2, shadowColor: Colors.black26, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)))),
          darkTheme: base.copyWith(textTheme: GoogleFonts.hindSiliguriTextTheme(base.textTheme).copyWith(titleLarge: const TextStyle(fontWeight: FontWeight.w900, fontSize: 22), bodyLarge: const TextStyle(fontSize: 16), bodyMedium: const TextStyle(fontSize: 15)), cardTheme: CardTheme(color: const Color(0xFF141B2E), elevation: 2, shadowColor: Colors.black45, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)))),
          home: !store.loaded ? Scaffold(body: SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: const [ShimmerBox(width: 300, height: 120), SizedBox(height: 16), ShimmerBox(width: 300, height: 56), SizedBox(height: 12), ShimmerBox(width: 300, height: 56)]))) : SplashGate(store: store),
        );
      },
    );
  }
}

class SplashGate extends StatefulWidget {
  final Store store;
  const SplashGate({super.key, required this.store});
  @override
  State<SplashGate> createState() => _SplashGateState();
}

class _SplashGateState extends State<SplashGate> {
  bool show = true;
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 2400), () {
      if (mounted) setState(() => show = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    if (show) {
      final s = widget.store;
      final letters = s.en ? ['A', 'd', 'd', 'a'] : ['আ', 'ড্ডা'];
      return Scaffold(
        body: Container(
          decoration: const BoxDecoration(gradient: LinearGradient(colors: [blueDark, blue, blueLight])),
          child: Stack(
            children: [
              Center(
                child: Row(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                FadeIn(delay: 0, child: const Text('a.', style: TextStyle(fontSize: 58, fontWeight: FontWeight.w900, color: Colors.white))),
                for (var i = 0; i < letters.length; i++) FadeIn(delay: 300 + i * 180, child: Text(letters[i], style: const TextStyle(fontSize: 58, fontWeight: FontWeight.w900, color: Colors.white))),
                FadeIn(delay: 300 + letters.length * 180, child: const Text('.', style: TextStyle(fontSize: 58, fontWeight: FontWeight.w900, color: amber))),
              ],
            ),
            ),
              const Positioned(
                left: 0,
                right: 0,
                bottom: 90,
                child: Center(child: _SplashShimmer()),
              ),
            ],
          ),
        ),
      );
    }
    return widget.store.me == null ? AuthScreen(store: widget.store) : HomeScreen(store: widget.store);
  }
}

class FadeIn extends StatefulWidget {
  final Widget child;
  final int delay;
  const FadeIn({super.key, required this.child, this.delay = 0});
  @override
  State<FadeIn> createState() => _FadeInState();
}

class _FadeInState extends State<FadeIn> {
  bool show = false;
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: widget.delay), () {
      if (mounted) setState(() => show = true);
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedOpacity(
      duration: const Duration(milliseconds: 320),
      opacity: show ? 1 : 0,
      child: Transform.translate(offset: Offset(0, show ? 0 : 14), child: widget.child),
    );
  }
}


class Pressable extends StatefulWidget {
  final Widget child;
  final VoidCallback onTap;
  const Pressable({super.key, required this.child, required this.onTap});
  @override
  State<Pressable> createState() => _PressableState();
}

class _PressableState extends State<Pressable> {
  bool pressed = false;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) {
        try {
          HapticFeedback.lightImpact();
        } catch (_) {}
        setState(() => pressed = true);
      },
      onTapUp: (_) => setState(() => pressed = false),
      onTapCancel: () => setState(() => pressed = false),
      onTap: widget.onTap,
      child: AnimatedScale(scale: pressed ? 0.93 : 1.0, duration: const Duration(milliseconds: 120), curve: Curves.easeOut, child: widget.child),
    );
  }
}

class PulseRing extends StatefulWidget {
  final Widget child;
  const PulseRing({super.key, required this.child});
  @override
  State<PulseRing> createState() => _PulseRingState();
}

class _PulseRingState extends State<PulseRing> with SingleTickerProviderStateMixin {
  late final AnimationController c;
  @override
  void initState() {
    super.initState();
    c = AnimationController(vsync: this, duration: const Duration(milliseconds: 3000))..repeat();
  }

  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: c,
      builder: (_, child) {
        final s = 1 + 0.04 * math.sin(c.value * 6.283185307);
        return Transform.scale(scale: s, child: child);
      },
      child: widget.child,
    );
  }
}

class SpringIn extends StatefulWidget {
  final Widget child;
  final int delay;
  const SpringIn({super.key, required this.child, this.delay = 0});
  @override
  State<SpringIn> createState() => _SpringInState();
}

class _SpringInState extends State<SpringIn> {
  bool show = false;
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: widget.delay), () {
      if (mounted) setState(() => show = true);
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedOpacity(
      duration: const Duration(milliseconds: 350),
      opacity: show ? 1 : 0,
      child: AnimatedScale(
        scale: show ? 1.0 : 0.96,
        duration: const Duration(milliseconds: 450),
        curve: Curves.easeOutBack,
        child: Transform.translate(offset: Offset(0, show ? 0 : 14), child: widget.child),
      ),
    );
  }
}

class ShimmerBox extends StatefulWidget {
  final double width;
  final double height;
  const ShimmerBox({super.key, required this.width, required this.height});
  @override
  State<ShimmerBox> createState() => _ShimmerBoxState();
}

class _ShimmerBoxState extends State<ShimmerBox> with SingleTickerProviderStateMixin {
  late final AnimationController c;
  @override
  void initState() {
    super.initState();
    c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))..repeat(reverse: true);
  }

  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: c,
      builder: (_, __) => Opacity(
        opacity: 0.35 + 0.4 * c.value,
        child: Container(width: widget.width, height: widget.height, decoration: BoxDecoration(color: Colors.grey, borderRadius: BorderRadius.circular(16))),
      ),
    );
  }
}

class _SplashShimmer extends StatefulWidget {
  const _SplashShimmer();
  @override
  State<_SplashShimmer> createState() => _SplashShimmerState();
}

class _SplashShimmerState extends State<_SplashShimmer> with SingleTickerProviderStateMixin {
  late final AnimationController c;
  @override
  void initState() {
    super.initState();
    c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1600))..repeat();
  }

  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: Container(
        width: 170,
        height: 6,
        decoration: BoxDecoration(color: Colors.white.withOpacity(0.25), borderRadius: BorderRadius.circular(8)),
        child: AnimatedBuilder(
          animation: c,
          builder: (_, __) => Align(
            alignment: Alignment(-1 + 2 * c.value, 0),
            child: Container(width: 60, decoration: BoxDecoration(color: Colors.white.withOpacity(0.85), borderRadius: BorderRadius.circular(8))),
          ),
        ),
      ),
    );
  }
}

Widget _codedPerson(Color shirt, Color skin) {
  return Column(
    mainAxisSize: MainAxisSize.min,
    children: [
      Container(width: 34, height: 34, decoration: BoxDecoration(color: skin, shape: BoxShape.circle)),
      const SizedBox(height: 2),
      Container(width: 58, height: 44, decoration: BoxDecoration(color: shirt, borderRadius: BorderRadius.circular(14))),
    ],
  );
}

class AnimatedWelcomeIllustration extends StatefulWidget {
  const AnimatedWelcomeIllustration({super.key});
  @override
  State<AnimatedWelcomeIllustration> createState() => _AnimatedWelcomeIllustrationState();
}

class _AnimatedWelcomeIllustrationState extends State<AnimatedWelcomeIllustration> with SingleTickerProviderStateMixin {
  late final AnimationController c;
  @override
  void initState() {
    super.initState();
    c = AnimationController(vsync: this, duration: const Duration(milliseconds: 6000))..repeat();
  }

  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 180,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: AnimatedBuilder(
          animation: c,
          builder: (_, __) {
            final t = c.value * 6.283185307;
            final bob1 = 8 * math.sin(t);
            final bob2 = 10 * math.sin(t + 1.5);
            return Stack(
              children: [
                Positioned.fill(
                  child: Container(
                    decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFFE4EDFB), Color(0xFFEDF2F9)])),
                    child: Stack(
                      children: [
                        Positioned(left: -20, top: 10, child: Container(width: 110, height: 110, decoration: BoxDecoration(color: blueLight.withOpacity(0.3), shape: BoxShape.circle))),
                        Positioned(right: -10, top: 30, child: Container(width: 80, height: 80, decoration: BoxDecoration(color: blue.withOpacity(0.15), shape: BoxShape.circle))),
                        Positioned(left: 26, bottom: 16, child: _codedPerson(blue, const Color(0xFFF2C29B))),
                        Positioned(right: 30, bottom: 16, child: _codedPerson(blueLight, const Color(0xFFF6D3AE))),
                        Positioned(left: 100, top: 22, child: Container(width: 44, height: 44, decoration: BoxDecoration(color: blue, borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.chat_bubble, color: Colors.white, size: 22))),
                      ],
                    ),
                  ),
                ),
                Positioned(left: 18, top: 20 + bob1, child: Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 8)]), child: const Text('💬', style: TextStyle(fontSize: 16)))),
                Positioned(right: 20, top: 58 + bob2, child: Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 8)]), child: const Text('❤️', style: TextStyle(fontSize: 16)))),
              ],
            );
          },
        ),
      ),
    );
  }
}

class VoiceNoteBubble extends StatefulWidget {
  const VoiceNoteBubble({super.key});
  @override
  State<VoiceNoteBubble> createState() => _VoiceNoteBubbleState();
}

class _VoiceNoteBubbleState extends State<VoiceNoteBubble> {
  bool playing = false;
  static const bars = [5.0, 10.0, 7.0, 14.0, 9.0, 16.0, 6.0, 12.0, 8.0, 15.0, 7.0, 11.0, 5.0, 13.0, 9.0, 6.0];
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          margin: const EdgeInsets.symmetric(vertical: 4),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(color: Colors.white, borderRadius: const BorderRadius.only(topLeft: Radius.circular(22), topRight: Radius.circular(22), bottomLeft: Radius.circular(6), bottomRight: Radius.circular(22)), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 8, offset: const Offset(0, 2))]),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              InkWell(
                onTap: () => setState(() => playing = !playing),
                borderRadius: BorderRadius.circular(20),
                child: Container(width: 36, height: 36, decoration: const BoxDecoration(color: blue, shape: BoxShape.circle), child: Icon(playing ? Icons.pause : Icons.play_arrow, color: Colors.white, size: 20)),
              ),
              const SizedBox(width: 10),
              Row(
                children: [
                  for (var i = 0; i < bars.length; i++)
                    Container(width: 3, height: bars[i], margin: const EdgeInsets.symmetric(horizontal: 1.5), decoration: BoxDecoration(color: i < 6 && playing ? blue : blueLight, borderRadius: BorderRadius.circular(2))),
                ],
              ),
              const SizedBox(width: 10),
              const Text('0:12', style: TextStyle(fontSize: 12, color: Colors.grey)),
            ],
          ),
        ),
        const Padding(
          padding: EdgeInsets.only(bottom: 4),
          child: Text('ভয়েস নোটের নমুনা — অডিও বাজে না', style: TextStyle(fontSize: 11, color: Colors.grey)),
        ),
      ],
    );
  }
}

Widget userAvatar(Account a, double size, {bool ring = false}) {
  final img = a.photo.isNotEmpty ? MemoryImage(base64Decode(a.photo)) : null;
  final circle = CircleAvatar(radius: size / 2, backgroundColor: blue, backgroundImage: img, child: img == null ? Text(a.name.isEmpty ? '?' : a.name[0], style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)) : null);
  Widget inner = Stack(
    clipBehavior: Clip.none,
    children: [
      circle,
      if (a.online) Positioned(right: 0, bottom: 0, child: Container(width: size * 0.28, height: size * 0.28, decoration: BoxDecoration(color: const Color(0xFF2ECC71), shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2)))),
    ],
  );
  if (ring && a.online) {
    return Container(padding: const EdgeInsets.all(3), decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [blue, blueLight, yellow])), child: inner);
  }
  return inner;
}

Widget talkyPill(String label, {bool selected = false, VoidCallback? onTap}) {
  return InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(20),
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(color: selected ? blue : Colors.white, borderRadius: BorderRadius.circular(20), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 8, offset: const Offset(0, 2))]),
      child: Text(label, style: TextStyle(color: selected ? Colors.white : blueDark, fontWeight: FontWeight.bold)),
    ),
  );
}

void showNote(BuildContext context, Store s, String title, String body) {
  showDialog(context: context, builder: (_) => AlertDialog(title: Text(title), content: Text(body), actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text(s.t('ঠিক আছে', 'OK')))]));
}
class AuthScreen extends StatefulWidget {
  final Store store;
  const AuthScreen({super.key, required this.store});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool creating = false;
  final nameC = TextEditingController();
  final userC = TextEditingController();
  final bioC = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final s = widget.store;
    return Scaffold(
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [TextButton(onPressed: () => s.toggleLanguage(), child: Text(s.en ? 'বাং' : 'EN'))],
          ),
          const AnimatedWelcomeIllustration(),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(28), gradient: const LinearGradient(colors: [blueDark, blue, blueLight]), boxShadow: [BoxShadow(color: blue.withOpacity(0.35), blurRadius: 20, offset: const Offset(0, 8))]),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(children: [Text('আড্ডা', style: TextStyle(fontSize: 44, fontWeight: FontWeight.w900, color: Colors.white)), Text('.', style: TextStyle(fontSize: 44, fontWeight: FontWeight.w900, color: amber))]),
                const SizedBox(height: 6),
                Text(s.t('সবার আড্ডায় স্বাগতম', "Welcome to everyone's Adda"), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white)),
                Text(s.t('বন্ধুদের সাথে আড্ডা জমে উঠুক', 'Chat away with your friends'), style: const TextStyle(color: Colors.white70)),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(child: Text(s.t('অ্যাকাউন্ট বেছে নিন', 'Choose an account'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
              if (s.accounts.isNotEmpty) Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: softCard, borderRadius: BorderRadius.circular(20)), child: Text(s.en ? '${s.accounts.length} accounts' : '${s.accounts.length}টি অ্যাকাউন্ট', style: const TextStyle(color: blueDark, fontWeight: FontWeight.bold, fontSize: 12))),
            ],
          ),
          const SizedBox(height: 10),
          for (final a in s.accounts)
            Card(
              child: ListTile(
                leading: userAvatar(a, 50),
                title: Text(a.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('@${a.username}${a.bio.isEmpty ? '' : ' · ${a.bio}'}'),
                trailing: FilledButton(onPressed: () => s.enter(a.id), style: FilledButton.styleFrom(backgroundColor: blue, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))), child: Text(s.t('ঢুকুন', 'Enter'))),
              ),
            ),
          const SizedBox(height: 14),
          FilledButton(
            onPressed: () => setState(() => creating = !creating),
            style: FilledButton.styleFrom(backgroundColor: blue, minimumSize: const Size.fromHeight(54), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
            child: Text(s.t('নতুন অ্যাকাউন্ট তৈরি করুন', 'Create a new account')),
          ),
          if (creating) ...[
            const SizedBox(height: 14),
            TextField(controller: nameC, decoration: InputDecoration(labelText: s.t('নাম', 'Name'), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)), filled: true, fillColor: Colors.white)),
            const SizedBox(height: 10),
            TextField(controller: userC, decoration: InputDecoration(labelText: s.t('ইউজারনেম', 'Username'), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)), filled: true, fillColor: Colors.white)),
            const SizedBox(height: 10),
            TextField(controller: bioC, decoration: InputDecoration(labelText: s.t('বায়ো', 'Bio'), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)), filled: true, fillColor: Colors.white)),
            const SizedBox(height: 10),
            FilledButton(
              onPressed: () async {
                await s.createAccount(nameC.text, userC.text, bioC.text);
              },
              style: FilledButton.styleFrom(backgroundColor: blueDark, minimumSize: const Size.fromHeight(52), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
              child: Text(s.t('তৈরি করুন', 'Create')),
            ),
          ],
        ],
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  final Store store;
  const HomeScreen({super.key, required this.store});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;
  Account? chatWith;
  Account? incomingCall;

  void openNotifications(Store s, Account me) {
    final incoming = s.requests.where((r) => r.to == me.id).toList();
    final unseen = s.messages.where((m) => m.to == me.id && !m.seen).toList();
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (_) => ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Center(child: Container(width: 40, height: 5, decoration: BoxDecoration(color: Colors.grey.withOpacity(0.4), borderRadius: BorderRadius.circular(3)))),
          const SizedBox(height: 12),
          Row(children: [Expanded(child: Text(s.t('নোটিফিকেশন', 'Notifications'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))), TextButton(onPressed: () {
            s.markAllSeen();
            Navigator.pop(context);
          }, child: Text(s.t('সব পড়া হয়েছে', 'Mark all read')))]),
          if (incoming.isEmpty && unseen.isEmpty) Text(s.t('কোনো নতুন নোটিফিকেশন নেই', 'No new notifications')),
          for (final r in incoming)
            Builder(builder: (_) {
              Account? from;
              for (final a in s.accounts) {
                if (a.id == r.from) from = a;
              }
              if (from == null) return const SizedBox();
              final f = from;
              return ListTile(
                leading: userAvatar(f, 44),
                title: Text(s.en ? '${f.name} sent you a friend request' : '${f.name} তোমাকে ফ্রেন্ড রিকোয়েস্ট পাঠিয়েছে'),
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [TextButton(onPressed: () {
                  s.respond(r.id, true);
                  Navigator.pop(context);
                }, child: Text(s.t('গ্রহণ', 'Accept'))), TextButton(onPressed: () {
                  s.respond(r.id, false);
                  Navigator.pop(context);
                }, child: Text(s.t('বাদ', 'Reject')))]),
              );
            }),
          for (final m in unseen)
            Builder(builder: (_) {
              Account? from;
              for (final a in s.accounts) {
                if (a.id == m.from) from = a;
              }
              if (from == null) return const SizedBox();
              final f = from;
              return ListTile(leading: userAvatar(f, 44), title: Text(f.name), subtitle: Text(m.text, maxLines: 1), onTap: () {
                Navigator.pop(context);
                setState(() => chatWith = f);
              });
            }),
        ],
      ),
    );
  }

  void openPlusSheet(Store s) {
    final nameC = TextEditingController();
    final userC = TextEditingController();
    final bioC = TextEditingController();
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(s.t('নতুন কিছু শুরু করুন', 'Start something new'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            ListTile(leading: const CircleAvatar(backgroundColor: blue, child: Icon(Icons.search, color: Colors.white)), title: Text(s.t('মানুষ খুঁজুন', 'Find people')), onTap: () {
              Navigator.pop(context);
              setState(() => tab = 2);
            }),
            const Divider(),
            TextField(controller: nameC, decoration: InputDecoration(labelText: s.t('নাম', 'Name'), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)))),
            const SizedBox(height: 8),
            TextField(controller: userC, decoration: InputDecoration(labelText: s.t('ইউজারনেম', 'Username'), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)))),
            const SizedBox(height: 8),
            TextField(controller: bioC, decoration: InputDecoration(labelText: s.t('বায়ো', 'Bio'), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)))),
            const SizedBox(height: 10),
            FilledButton(
              onPressed: () async {
                await s.createAccount(nameC.text, userC.text, bioC.text);
                if (mounted) Navigator.pop(context);
              },
              style: FilledButton.styleFrom(backgroundColor: blue, minimumSize: const Size.fromHeight(50), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
              child: Text(s.t('নতুন অ্যাকাউন্ট তৈরি করুন', 'Create a new account')),
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  Widget navItem(Store s, IconData icon, String label, int index) {
    final selected = tab == index;
    return Expanded(
      child: Pressable(
        onTap: () => setState(() => tab = index),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          curve: Curves.elasticOut,
          padding: const EdgeInsets.symmetric(vertical: 10),
          constraints: const BoxConstraints(minHeight: 48),
          decoration: BoxDecoration(color: selected ? blue : Colors.transparent, borderRadius: BorderRadius.circular(20)),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: selected ? Colors.white : Colors.grey, size: 22),
              Text(label, style: TextStyle(fontSize: 11, color: selected ? Colors.white : Colors.grey, fontWeight: FontWeight.bold)),
              AnimatedOpacity(duration: const Duration(milliseconds: 250), opacity: selected ? 1 : 0, child: Container(width: 5, height: 5, margin: const EdgeInsets.only(top: 3), decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle))),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.store;
    final me = s.me!;
    if (chatWith != null) return ChatScreen(store: s, me: me, friend: chatWith!, onBack: () => setState(() => chatWith = null));
    Widget body;
    if (tab == 0) {
      body = MessagesTab(store: s, me: me, onChat: (a) => setState(() => chatWith = a));
    } else if (tab == 1) {
      body = FriendsTab(store: s, me: me, onChat: (a) => setState(() => chatWith = a));
    } else if (tab == 2) {
      body = PeopleTab(store: s, me: me, onChat: (a) => setState(() => chatWith = a));
    } else {
      body = ProfileTab(store: s, me: me);
    }
    final notifCount = s.totalUnseen + s.incomingRequestCount;
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 12, 20, 4),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(s.en ? 'Adda.' : 'আড্ডা.', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: blueDark)),
                          ],
                        ),
                      ),
                      IconButton(icon: const Icon(Icons.search), onPressed: () => setState(() => tab = 2)),
                      Stack(
                        clipBehavior: Clip.none,
                        children: [
                          IconButton(icon: const Icon(Icons.notifications_outlined), onPressed: () => openNotifications(s, me)),
                          if (notifCount > 0) Positioned(right: 6, top: 6, child: Container(padding: const EdgeInsets.all(4), decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle), constraints: const BoxConstraints(minWidth: 18, minHeight: 18), child: Text('${notifCount > 9 ? '9+' : notifCount}', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)))),
                        ],
                      ),
                      const SizedBox(width: 4),
                      InkWell(onTap: () => setState(() => tab = 3), child: userAvatar(me, 42)),
                    ],
                  ),
                ),
                Expanded(child: AnimatedSwitcher(duration: const Duration(milliseconds: 300), transitionBuilder: (child, anim) { final curved = CurvedAnimation(parent: anim, curve: Curves.easeOutCubic); return FadeTransition(opacity: curved, child: SlideTransition(position: Tween<Offset>(begin: const Offset(0, 0.04), end: Offset.zero).animate(curved), child: child)); }, child: Container(key: ValueKey(tab), child: body))),
              ],
            ),
            if (incomingCall != null)
              Positioned(
                left: 16,
                right: 16,
                bottom: 8,
                child: TweenAnimationBuilder<double>(
                  tween: Tween(begin: 0, end: 1),
                  duration: const Duration(milliseconds: 350),
                  curve: Curves.easeOutBack,
                  builder: (_, v, child) => Opacity(opacity: v, child: Transform.translate(offset: Offset(0, 48 * (1 - v)), child: child)),
                  child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.15), blurRadius: 20, offset: const Offset(0, 6))]),
                  child: Row(
                    children: [
                      userAvatar(incomingCall!, 50),
                      const SizedBox(width: 12),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(incomingCall!.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), Text(s.t('ইনকামিং কল', 'Incoming call'), style: const TextStyle(color: slate, fontSize: 12))])),
                      IconButton.filled(onPressed: () { final f = incomingCall; setState(() => incomingCall = null); if (f != null) Navigator.push(context, MaterialPageRoute(builder: (_) => CallScreen(store: s, me: me, friend: f, kind: 'audio'))); }, style: IconButton.styleFrom(backgroundColor: blue), icon: const Icon(Icons.call, color: Colors.white)),
                      const SizedBox(width: 6),
                      IconButton.filled(onPressed: () => setState(() => incomingCall = null), style: IconButton.styleFrom(backgroundColor: Colors.red), icon: const Icon(Icons.call_end, color: Colors.white)),
                    ],
                  ),
                ),
                ),
              ),
            if (s.justCreated) ConfettiOverlay(onDone: () => s.clearCelebration()),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        margin: EdgeInsets.zero,
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        decoration: BoxDecoration(color: Theme.of(context).colorScheme.surface.withOpacity(0.88), border: Border(top: BorderSide(color: Colors.black.withOpacity(0.06))), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, -2))]),
        child: Row(
          children: [
            navItem(s, Icons.chat_bubble_outline, s.t('মেসেজ', 'Messages'), 0),
            navItem(s, Icons.people_outline, s.t('বন্ধু', 'Friends'), 1),
            navItem(s, Icons.person_search_outlined, s.t('মানুষ', 'People'), 2),
            navItem(s, Icons.person_outline, s.t('প্রোফাইল', 'Profile'), 3),
          ],
        ),
      ),
    );
  }
}

class ConfettiOverlay extends StatefulWidget {
  final VoidCallback onDone;
  const ConfettiOverlay({super.key, required this.onDone});
  @override
  State<ConfettiOverlay> createState() => _ConfettiOverlayState();
}

class _ConfettiOverlayState extends State<ConfettiOverlay> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 2200), () {
      if (mounted) widget.onDone();
    });
  }

  @override
  Widget build(BuildContext context) {
    const dots = [Offset(-90, -60), Offset(90, -70), Offset(-60, 60), Offset(70, 70), Offset(0, -100), Offset(-110, 0), Offset(110, 10), Offset(-40, -110), Offset(50, -90), Offset(0, 100)];
    const colors = [blue, blueLight, yellow, amber, Colors.pink, Colors.orange];
    return IgnorePointer(
      child: Center(
        child: Stack(
          alignment: Alignment.center,
          children: [
            for (var i = 0; i < dots.length; i++)
              TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: 1),
                duration: const Duration(milliseconds: 900),
                builder: (_, v, __) => Transform.translate(offset: dots[i] * v, child: Opacity(opacity: 1 - v * 0.4, child: Container(width: 10, height: 10, decoration: BoxDecoration(color: colors[i % colors.length], shape: BoxShape.circle)))),
              ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 16),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.15), blurRadius: 20)]),
              child: const Column(mainAxisSize: MainAxisSize.min, children: [Text('✓', style: TextStyle(fontSize: 30, color: blue, fontWeight: FontWeight.bold)), Text('স্বাগতম!', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: blueDark))]),
            ),
          ],
        ),
      ),
    );
  }
}

class MessagesTab extends StatefulWidget {
  final Store store;
  final Account me;
  final void Function(Account) onChat;
  const MessagesTab({super.key, required this.store, required this.me, required this.onChat});
  @override
  State<MessagesTab> createState() => _MessagesTabState();
}

class _MessagesTabState extends State<MessagesTab> {
  int filter = 0;
  int mode = 0; // 0 = Chat (Talky list), 1 = Call
  String mq = '';
  @override
  Widget build(BuildContext context) {
    final s = widget.store;
    final me = widget.me;
    final friends = s.friendsOf(me.id);
    final chatFriends = friends.where((f) => s.messages.any((m) => (m.from == me.id && m.to == f.id) || (m.from == f.id && m.to == me.id)) && (mq.isEmpty || f.name.toLowerCase().contains(mq.toLowerCase()) || f.username.toLowerCase().contains(mq.toLowerCase()))).toList()
      ..sort((a, b) {
        final ma = s.messages.where((m) => (m.from == me.id && m.to == a.id) || (m.from == a.id && m.to == me.id)).toList();
        final mb = s.messages.where((m) => (m.from == me.id && m.to == b.id) || (m.from == b.id && m.to == me.id)).toList();
        final ta = ma.isEmpty ? 0 : ma.last.createdAt;
        final tb = mb.isEmpty ? 0 : mb.last.createdAt;
        return tb.compareTo(ta);
      });
    final incoming = s.requests.where((r) => r.to == me.id).toList();
    return Column(
      children: [
        Container(
          margin: const EdgeInsets.fromLTRB(16, 8, 16, 4),
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: const LinearGradient(colors: [blueDark, blue, blueLight]), boxShadow: [BoxShadow(color: blue.withOpacity(0.35), blurRadius: 20, offset: const Offset(0, 8))]),
          child: Stack(
            children: [
              const Positioned(right: -6, bottom: -18, child: Opacity(opacity: 0.14, child: Text('আড্ডা', style: TextStyle(fontSize: 64, fontWeight: FontWeight.w900, color: Colors.white)))),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [Expanded(child: Text(s.t('মেসেজ', 'Messages'), style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: Colors.white))), userAvatar(me, 42)]),
                  const SizedBox(height: 4),
                  Text(s.t('বন্ধুদের সাথে আড্ডা জমে উঠুক', 'Chat away with your friends'), style: const TextStyle(color: Colors.white70)),
                  const SizedBox(height: 12),
                  Wrap(spacing: 8, runSpacing: 8, children: [
                    Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5), decoration: BoxDecoration(color: Colors.white.withOpacity(0.22), borderRadius: BorderRadius.circular(20)), child: Text(s.en ? '${friends.length} friends' : '${friends.length} বন্ধু', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12))),
                    Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5), decoration: BoxDecoration(color: Colors.white.withOpacity(0.22), borderRadius: BorderRadius.circular(20)), child: Text(s.en ? '${chatFriends.length} chats' : '${chatFriends.length} চ্যাট', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12))),
                    Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5), decoration: BoxDecoration(color: Colors.white.withOpacity(0.22), borderRadius: BorderRadius.circular(20)), child: Text(s.en ? '${incoming.length} requests' : '${incoming.length} রিকোয়েস্ট', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12))),
                  ]),
                ],
              ),
            ],
          ),
        ),
        Expanded(
          child: Container(
            margin: const EdgeInsets.fromLTRB(12, 4, 12, 0),
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
            decoration: BoxDecoration(color: Theme.of(context).brightness == Brightness.dark ? const Color(0xFF141B2E) : Colors.white, borderRadius: const BorderRadius.only(topLeft: Radius.circular(28), topRight: Radius.circular(28))),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(color: softCard, borderRadius: BorderRadius.circular(20)),
                  child: Row(children: [
                    Expanded(child: GestureDetector(onTap: () => setState(() => mode = 0), child: Container(padding: const EdgeInsets.symmetric(vertical: 8), decoration: BoxDecoration(color: mode == 0 ? blue : Colors.transparent, borderRadius: BorderRadius.circular(16)), child: Text(s.t('চ্যাট', 'Chat'), textAlign: TextAlign.center, style: TextStyle(color: mode == 0 ? Colors.white : Colors.black87, fontWeight: FontWeight.bold))))),
                    Expanded(child: GestureDetector(onTap: () => setState(() => mode = 1), child: Container(padding: const EdgeInsets.symmetric(vertical: 8), decoration: BoxDecoration(color: mode == 1 ? blue : Colors.transparent, borderRadius: BorderRadius.circular(16)), child: Text(s.t('কল', 'Call'), textAlign: TextAlign.center, style: TextStyle(color: mode == 1 ? Colors.white : Colors.black87, fontWeight: FontWeight.bold))))),
                  ]),
                ),
                const SizedBox(height: 10),
                if (mode == 0) TextField(onChanged: (v) => setState(() => mq = v), decoration: InputDecoration(hintText: s.t('চ্যাট খুঁজুন…', 'Search chats…'), prefixIcon: const Icon(Icons.search), filled: true, fillColor: softCard, border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide.none))),
                if (mode == 0) const SizedBox(height: 10),
                Row(children: [
                  talkyPill(s.t('প্রাইভেট', 'Private'), selected: filter == 0, onTap: () => setState(() => filter = 0)),
                  const SizedBox(width: 8),
                  talkyPill(s.t('গ্রুপ', 'Group'), selected: filter == 1, onTap: () => setState(() => filter = 1)),
                  const SizedBox(width: 8),
                  talkyPill(s.t('রিকোয়েস্ট', 'Requests'), selected: filter == 2, onTap: () => setState(() => filter = 2)),
                  const Spacer(),
                  if (incoming.isNotEmpty) Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: Colors.red, borderRadius: BorderRadius.circular(12)), child: Text('${incoming.length}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12))),
                ]),
                const SizedBox(height: 12),
                Expanded(
                  child: mode == 1
                      ? CallsTab(store: s, me: me, onCall: (a) => widget.onChat(a))
                      : filter == 1
                      ? Center(child: Text(s.t('গ্রুপ চ্যাট এখনো আসেনি', 'Group chats are not available yet'), textAlign: TextAlign.center))
                      : filter == 2
                          ? (incoming.isEmpty
                              ? Center(child: Text(s.t('কোনো রিকোয়েস্ট নেই', 'No requests')))
                              : ListView(
                                  children: [
                                    for (final r in incoming)
                                      Builder(builder: (_) {
                                        Account? from;
                                        for (final a in s.accounts) {
                                          if (a.id == r.from) from = a;
                                        }
                                        if (from == null) return const SizedBox();
                                        final f = from;
                                        return ListTile(
                                          leading: userAvatar(f, 48),
                                          title: Text(f.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                                          subtitle: Text('@${f.username}'),
                                          trailing: Row(mainAxisSize: MainAxisSize.min, children: [TextButton(onPressed: () => s.respond(r.id, true), child: Text(s.t('গ্রহণ', 'Accept'))), TextButton(onPressed: () => s.respond(r.id, false), child: Text(s.t('বাদ', 'Reject')))]),
                                        );
                                      }),
                                  ],
                                ))
                          : RefreshIndicator(
                              onRefresh: () async {
                                await Future.delayed(const Duration(milliseconds: 500));
                                if (mounted) setState(() {});
                              },
                              child: ListView(
                                children: [
                                  for (var i = 0; i < chatFriends.length; i++)
                                  Builder(builder: (_) {
                                    final f = chatFriends[i];
                                    final msgs = s.messages.where((m) => (m.from == me.id && m.to == f.id) || (m.from == f.id && m.to == me.id)).toList();
                                    final last = msgs.isEmpty ? null : msgs.last;
                                    final unread = s.unseenFrom(f.id);
                                    return SpringIn(
                                      delay: i * 70,
                                      child: Container(
                                        margin: const EdgeInsets.only(bottom: 4),
                                        decoration: BoxDecoration(color: unread > 0 ? softCard : null, borderRadius: BorderRadius.circular(18)),
                                        child: ListTile(
                                          leading: userAvatar(f, 50, ring: true),
                                          title: Text(f.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                                          subtitle: Text(last == null ? s.t('চ্যাট শুরু করুন', 'Start chatting') : (last.attachKind.isNotEmpty ? '📎 ${last.attachName.isEmpty ? s.t('ফাইল', 'File') : last.attachName}' : last.text), maxLines: 1),
                                          trailing: Column(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            crossAxisAlignment: CrossAxisAlignment.end,
                                            children: [
                                              Text(last == null ? '' : s.relTime(last.createdAt), style: const TextStyle(fontSize: 11, color: Colors.grey)),
                                              if (unread > 0) ...[const SizedBox(height: 4), CircleAvatar(radius: 10, backgroundColor: blue, child: Text('$unread', style: const TextStyle(color: Colors.white, fontSize: 11)))],
                                            ],
                                          ),
                                          onTap: () => widget.onChat(f),
                                        ),
                                      ),
                                    );
                                  }),
                                if (chatFriends.isEmpty)
                                  Padding(
                                    padding: const EdgeInsets.only(top: 24),
                                    child: Column(
                                      children: [
                                        Container(width: 72, height: 72, decoration: BoxDecoration(color: softCard, shape: BoxShape.circle), child: const Icon(Icons.chat_bubble_outline, color: blue, size: 34)),
                                        const SizedBox(height: 12),
                                        Text(s.t('এখনো কোনো চ্যাট নেই', 'No chats yet'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                                        const SizedBox(height: 4),
                                        Text(s.t('মানুষ ট্যাব থেকে বন্ধু বানিয়ে আড্ডা শুরু করো।', 'Make friends from the People tab and start chatting.'), textAlign: TextAlign.center),
                                      ],
                                    ),
                                  ),
                              ],
                            ),
                          ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class CallsTab extends StatelessWidget {
  final Store store;
  final Account me;
  final void Function(Account)? onCall;
  const CallsTab({super.key, required this.store, required this.me, this.onCall});
  @override
  Widget build(BuildContext context) {
    final s = store;
    final friends = s.friendsOf(me.id);
    return RefreshIndicator(
      onRefresh: () async => await Future.delayed(const Duration(milliseconds: 500)),
      child: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)),
          child: Text(s.t('টেস্ট সিস্টেম: দুই পাশে অ্যাপ খোলা থাকলে কল সংযোগ হবে। আসল দুই ডিভাইসের কল পেতে হোস্টেড সার্ভার লাগবে।', 'Test system: both sides must have the app open. A hosted server is needed for real two-device calls.'), textAlign: TextAlign.center),
        ),
        const SizedBox(height: 12),
        for (final f in friends)
          SpringIn(
            delay: friends.indexOf(f) * 70,
            child: Card(
            child: ListTile(
              leading: userAvatar(f, 50, ring: true),
              title: Text(f.name, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(f.online ? s.t('এখন অনলাইনে আছে', 'Online now') : (f.lastSeen > 0 ? '${s.t('শেষ দেখা', 'Last seen')} ${s.relTime(f.lastSeen)}' : s.t('অফলাইন', 'Offline'))),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(icon: const Icon(Icons.call, color: blue), onPressed: () { if (onCall != null) { onCall!(f); } else { Navigator.push(context, MaterialPageRoute(builder: (_) => CallScreen(store: s, me: me, friend: f, kind: 'audio'))); } }),
                  IconButton(icon: const Icon(Icons.videocam, color: blue), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CallScreen(store: s, me: me, friend: f, kind: 'video')))),
                ],
              ),
            ),
            ),
          ),
        if (friends.isEmpty) Padding(padding: const EdgeInsets.only(top: 24), child: Column(children: [Container(width: 72, height: 72, decoration: BoxDecoration(color: softCard, shape: BoxShape.circle), child: const Icon(Icons.call_outlined, color: blue, size: 34)), const SizedBox(height: 12), Text(s.t('এখনো কোনো বন্ধু নেই', 'No friends yet'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), const SizedBox(height: 4), Text(s.t('মানুষ ট্যাব থেকে বন্ধু বানালে এখানে কল করা যাবে।', 'Make friends from the People tab to call them here.'), textAlign: TextAlign.center)])),
      ],
      ),
    );
  }
}

class FriendsTab extends StatelessWidget {
  final Store store;
  final Account me;
  final void Function(Account) onChat;
  const FriendsTab({super.key, required this.store, required this.me, required this.onChat});
  @override
  Widget build(BuildContext context) {
    final s = store;
    final friends = s.friendsOf(me.id);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(padding: const EdgeInsets.fromLTRB(20, 8, 20, 4), child: Text(s.t('বন্ধুরা (${friends.length})', 'Friends (${friends.length})'), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: blueDark))),
        Expanded(
          child: friends.isEmpty
              ? Padding(padding: const EdgeInsets.only(top: 24), child: Column(children: [Container(width: 72, height: 72, decoration: BoxDecoration(color: softCard, shape: BoxShape.circle), child: const Icon(Icons.people_outline, color: blue, size: 34)), const SizedBox(height: 12), Text(s.t('এখনো কোনো বন্ধু নেই', 'No friends yet'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), const SizedBox(height: 4), Text(s.t('মানুষ ট্যাব থেকে বন্ধু বানালে এখানে দেখা যাবে।', 'Make friends from the People tab to see them here.'), textAlign: TextAlign.center)]))
              : RefreshIndicator(
                  onRefresh: () async { await Future.delayed(const Duration(milliseconds: 400)); },
                  child: ListView(
                    children: [
                      for (final f in friends)
                        ListTile(
                          leading: userAvatar(f, 50, ring: f.online),
                          title: Text(f.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                          subtitle: Text(f.online ? s.t('এখন অনলাইনে আছে', 'Online now') : (f.lastSeen > 0 ? '${s.t('শেষ দেখা', 'Last seen')} ${s.relTime(f.lastSeen)}' : s.t('অফলাইন', 'Offline'))),
                          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                            IconButton(icon: const Icon(Icons.chat_bubble_outline, color: blue), onPressed: () => onChat(f)),
                            IconButton(icon: const Icon(Icons.call, color: blue), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CallScreen(store: s, me: me, friend: f, kind: 'audio')))),
                            IconButton(icon: const Icon(Icons.videocam, color: blue), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CallScreen(store: s, me: me, friend: f, kind: 'video')))),
                          ]),
                          onTap: () => onChat(f),
                        ),
                    ],
                  ),
                ),
        ),
      ],
    );
  }
}

class PeopleTab extends StatefulWidget {
  final Store store;
  final Account me;
  final void Function(Account) onChat;
  const PeopleTab({super.key, required this.store, required this.me, required this.onChat});
  @override
  State<PeopleTab> createState() => _PeopleTabState();
}

class _PeopleTabState extends State<PeopleTab> {
  String q = '';
  String? selectedId;
  @override
  Widget build(BuildContext context) {
    final s = widget.store;
    final me = widget.me;
    final incoming = s.requests.where((r) => r.to == me.id).toList();
    final others = s.accounts.where((a) => a.id != me.id && (q.isEmpty || a.name.toLowerCase().contains(q.toLowerCase()) || a.username.toLowerCase().contains(q.toLowerCase()))).toList();
    Account? selected;
    for (final a in others) {
      if (a.id == selectedId) selected = a;
    }
    return RefreshIndicator(
      onRefresh: () async => await Future.delayed(const Duration(milliseconds: 500)),
      child: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(s.t('মানুষ খুঁজুন', 'Find people'), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: blueDark)),
        const SizedBox(height: 12),
        TextField(
          onChanged: (v) => setState(() => q = v),
          decoration: InputDecoration(hintText: s.t('নাম বা @ইউজারনেম দিয়ে খুঁজুন...', 'Search by name or @username...'), prefixIcon: const Icon(Icons.search), filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide.none)),
        ),
        if (incoming.isNotEmpty) ...[
          const SizedBox(height: 12),
          Text(s.t('ফ্রেন্ড রিকোয়েস্ট এসেছে', 'Friend requests'), style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
        for (final r in incoming)
          Builder(builder: (_) {
            Account? from;
            for (final a in s.accounts) {
              if (a.id == r.from) from = a;
            }
            if (from == null) return const SizedBox();
            final f2 = from;
            return Card(
              child: ListTile(
                leading: userAvatar(f2, 48),
                title: Text(f2.name),
                subtitle: Text('@${f2.username}'),
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [TextButton(onPressed: () => s.respond(r.id, true), child: Text(s.t('গ্রহণ', 'Accept'))), TextButton(onPressed: () => s.respond(r.id, false), child: Text(s.t('বাদ', 'Reject')))]),
              ),
            );
          }),
        const SizedBox(height: 12),
        for (final a in others)
          SpringIn(
            delay: others.indexOf(a) * 60,
            child: Card(
            color: selectedId == a.id ? softCard : null,
            child: ListTile(
              leading: userAvatar(a, 48, ring: true),
              title: Text(a.name, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(s.areFriends(me.id, a.id) ? s.t('বন্ধু', 'Friend') : '@${a.username}'),
              trailing: const Icon(Icons.chat_bubble_outline, color: blue),
              onTap: () => setState(() => selectedId = a.id),
            ),
            ),
          ),
        if (others.isEmpty && incoming.isEmpty) Padding(padding: const EdgeInsets.only(top: 24), child: Column(children: [Container(width: 72, height: 72, decoration: BoxDecoration(color: softCard, shape: BoxShape.circle), child: const Icon(Icons.people_outline, color: blue, size: 34)), const SizedBox(height: 12), Text(s.t('কাউকে পাওয়া যায়নি', 'Nobody found yet'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), const SizedBox(height: 4), Text(s.t('নতুন অ্যাকাউন্ট তৈরি করলে এখানে দেখা যাবে।', 'New accounts will appear here once created.'), textAlign: TextAlign.center)])),
        if (selected != null) ...[
          const SizedBox(height: 16),
          _personDetail(context, s, me, selected),
        ],
      ],
      ),
    );
  }

  Widget _personDetail(BuildContext context, Store s, Account me, Account p) {
    final isFriend = s.areFriends(me.id, p.id);
    Req? incoming;
    for (final r in s.requests) {
      if (r.from == p.id && r.to == me.id) incoming = r;
    }
    final outgoing = s.requests.any((r) => r.from == me.id && r.to == p.id);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              userAvatar(p, 56, ring: true),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(p.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), Text('@${p.username}'), Text(p.online ? s.t('এখন অনলাইনে আছে', 'Online now') : (p.lastSeen > 0 ? '${s.t('শেষ দেখা', 'Last seen')} ${s.relTime(p.lastSeen)}' : s.t('অফলাইন', 'Offline')), style: const TextStyle(color: blue))])),
            ]),
            if (p.bio.isNotEmpty) ...[const SizedBox(height: 8), Text(p.bio)],
            const SizedBox(height: 14),
            if (isFriend)
              FilledButton.icon(onPressed: () => widget.onChat(p), icon: const Icon(Icons.chat_bubble_outline), label: Text(s.t('মেসেজ করুন', 'Message')), style: FilledButton.styleFrom(backgroundColor: blue, minimumSize: const Size.fromHeight(50), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))))
            else if (incoming != null)
              Row(children: [Expanded(child: FilledButton(onPressed: () => s.respond(incoming!.id, true), style: FilledButton.styleFrom(backgroundColor: blue), child: Text(s.t('গ্রহণ', 'Accept')))), const SizedBox(width: 8), Expanded(child: OutlinedButton(onPressed: () => s.respond(incoming!.id, false), child: Text(s.t('বাদ', 'Reject'))))])
            else if (outgoing)
              Row(children: [Expanded(child: OutlinedButton(onPressed: () => s.cancelRequest(p.id), child: Text(s.t('রিকোয়েস্ট বাতিল', 'Cancel request')))), const SizedBox(width: 8), Expanded(child: Text(s.t('পাঠানো হয়েছে', 'Sent'), textAlign: TextAlign.center, style: const TextStyle(color: Colors.grey)))])
            else
              FilledButton(onPressed: () => s.sendRequest(p.id), style: FilledButton.styleFrom(backgroundColor: blue, minimumSize: const Size.fromHeight(50), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))), child: Text(s.t('ফ্রেন্ড রিকোয়েস্ট পাঠান', 'Send friend request'))),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: OutlinedButton.icon(onPressed: isFriend ? () => Navigator.push(context, MaterialPageRoute(builder: (_) => CallScreen(store: s, me: me, friend: p, kind: 'audio'))) : null, icon: const Icon(Icons.call), label: Text(s.t('কল', 'Call')))),
              const SizedBox(width: 8),
              Expanded(child: OutlinedButton.icon(onPressed: isFriend ? () => Navigator.push(context, MaterialPageRoute(builder: (_) => CallScreen(store: s, me: me, friend: p, kind: 'video'))) : null, icon: const Icon(Icons.videocam), label: Text(s.t('ভিডিও', 'Video')))),
            ]),
            if (isFriend) ...[
              const SizedBox(height: 8),
              SizedBox(width: double.infinity, child: OutlinedButton(onPressed: () => s.unfriend(p.id), style: OutlinedButton.styleFrom(foregroundColor: Colors.red), child: Text(s.t('আনফ্রেন্ড', 'Unfriend')))),
            ],
          ],
        ),
      ),
    );
  }
}

class ProfileTab extends StatelessWidget {
  final Store store;
  final Account me;
  const ProfileTab({super.key, required this.store, required this.me});

  Future<void> pickPhoto(BuildContext context, Store s, bool cover) async {
    try {
      final f = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 70, maxWidth: 900);
      if (f == null) return;
      final bytes = await f.readAsBytes();
      if (bytes.lengthInBytes > 20 * 1024 * 1024) {
        if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.t('ফাইল ২০ MB-এর বেশি', 'File is over 20 MB'))));
        return;
      }
      s.setPhoto(cover, base64Encode(bytes));
    } catch (_) {
      if (context.mounted) showNote(context, s, s.t('ছবি বাছাই', 'Pick photo'), s.t('এই ডিভাইসে ছবি বাছাই করা যায়নি।', 'Photo picking is not available on this device.'));
    }
  }

  Future<void> deleteFlow(BuildContext context, Store s, Account m) async {
    final ctrl = TextEditingController();
    var typedOk = false;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: Text(s.t('অ্যাকাউন্ট মুছুন?', 'Delete account?')),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(s.t('সব মেসেজ ও বন্ধুত্ব স্থায়ীভাবে মুছে যাবে। নিশ্চিত করতে @ইউজারনেমটি হুবহু লিখুন:', 'All messages and friendships will be permanently deleted. Type the exact @username to confirm:')),
              const SizedBox(height: 12),
              TextField(controller: ctrl, decoration: InputDecoration(hintText: '@${m.username}', border: const OutlineInputBorder()), onChanged: (v) => setD(() => typedOk = v.trim() == '@${m.username}' || v.trim() == m.username)),
            ],
          ),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(s.t('বাতিল', 'Cancel'))), FilledButton(onPressed: typedOk ? () => Navigator.pop(ctx, true) : null, style: FilledButton.styleFrom(backgroundColor: Colors.red), child: Text(s.t('মুছুন', 'Delete')))],
        ),
      ),
    );
    if (ok == true) s.deleteAccount(m.id);
  }

  Future<void> editProfile(BuildContext context, Store s, Account m) async {
    final nameC = TextEditingController(text: m.name);
    final bioC = TextEditingController(text: m.bio);
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(s.t('প্রোফাইল সম্পাদনা করুন', 'Edit profile')),
        content: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: nameC, decoration: InputDecoration(labelText: s.t('নাম', 'Name'), border: const OutlineInputBorder())), const SizedBox(height: 8), TextField(controller: bioC, decoration: InputDecoration(labelText: s.t('বায়ো', 'Bio'), border: const OutlineInputBorder()))]),
        actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: Text(s.t('বাতিল', 'Cancel'))), FilledButton(onPressed: () => Navigator.pop(context, true), style: FilledButton.styleFrom(backgroundColor: blue), child: Text(s.t('সংরক্ষণ', 'Save')))],
      ),
    );
    if (ok == true) s.updateProfile(nameC.text, bioC.text);
  }

  @override
  Widget build(BuildContext context) {
    final s = store;
    final friends = s.friendsOf(me.id).length;
    final chats = s.messages.where((m) => m.from == me.id || m.to == me.id).map((m) => m.from == me.id ? m.to : m.from).toSet().length;
    final reqs = s.incomingRequestCount;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (me.cover.isNotEmpty)
          Container(height: 80, margin: const EdgeInsets.only(bottom: 8), decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), image: DecorationImage(image: MemoryImage(base64Decode(me.cover)), fit: BoxFit.cover))),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                Stack(
                  clipBehavior: Clip.none,
                  children: [
                    userAvatar(me, 92, ring: true),
                    Positioned(
                      right: -2,
                      bottom: -2,
                      child: InkWell(
                        onTap: () => pickPhoto(context, s, false),
                        child: Container(padding: const EdgeInsets.all(7), decoration: const BoxDecoration(color: blue, shape: BoxShape.circle), child: const Icon(Icons.camera_alt, size: 16, color: Colors.white)),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(me.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: softCard, borderRadius: BorderRadius.circular(20)), child: Row(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.verified, size: 14, color: blue), const SizedBox(width: 4), Text('@${me.username}', style: const TextStyle(color: blueDark, fontWeight: FontWeight.bold))])),
                if (me.bio.isNotEmpty) ...[const SizedBox(height: 8), Text(me.bio, textAlign: TextAlign.center)],
                const SizedBox(height: 12),
                Text(s.en ? '$friends friends · $chats chats · $reqs requests' : '$friends বন্ধু · $chats চ্যাট · $reqs রিকোয়েস্ট', style: const TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6), decoration: BoxDecoration(color: softCard, borderRadius: BorderRadius.circular(20)), child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(me.online ? Icons.circle : Icons.circle_outlined, size: 12, color: me.online ? blue : Colors.grey), const SizedBox(width: 6), Text(me.online ? s.t('Available', 'Available') : s.t('অফলাইন', 'Offline'), style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(width: 4), Switch(value: me.online, activeColor: blue, onChanged: (_) => s.toggleOnline())])),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(s.t('ছবি', 'Photos'), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
              const SizedBox(height: 4),
              Text(s.t('প্লেসহোল্ডার টাইল — আসল ছবি নয়', 'Placeholder tiles only — not real photos'), style: const TextStyle(color: Colors.grey, fontSize: 12)),
              const SizedBox(height: 12),
              GridView.count(crossAxisCount: 3, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), mainAxisSpacing: 8, crossAxisSpacing: 8, children: [for (var i = 0; i < 6; i++) Container(decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), gradient: LinearGradient(colors: [softCard, Colors.white])), child: Icon(i.isEven ? Icons.image_outlined : Icons.photo_outlined, color: blue))]),
            ]),
          ),
        ),
        const SizedBox(height: 12),
        Card(
          child: Column(children: [
            ListTile(leading: const Icon(Icons.edit, color: blue), title: Text(s.t('প্রোফাইল সম্পাদনা করুন', 'Edit profile')), subtitle: Text(s.t('নাম, বায়ো ও তথ্য বদলান', 'Change name, bio and info')), trailing: const Icon(Icons.chevron_right), onTap: () => editProfile(context, s, me)),
            ListTile(leading: const Icon(Icons.camera_alt, color: blue), title: Text(s.t('প্রোফাইল ছবি', 'Profile photo')), trailing: const Icon(Icons.chevron_right), onTap: () => pickPhoto(context, s, false)),
            ListTile(leading: const Icon(Icons.image, color: blue), title: Text(s.t('কভার ছবি', 'Cover photo')), subtitle: Text(s.t('উপরে ছোট ব্যানার হিসেবে দেখাবে', 'Shows as a small banner above')), trailing: const Icon(Icons.chevron_right), onTap: () => pickPhoto(context, s, true)),
          ]),
        ),
        const SizedBox(height: 12),
        Card(
          child: Column(children: [
            ListTile(leading: const Icon(Icons.wb_sunny, color: blue), title: Text(s.t('থিম', 'Theme')), subtitle: Text(s.theme == 'light' ? 'Light' : s.theme == 'dark' ? 'Dark' : s.t('ডিভাইস', 'Device')), trailing: Text(s.theme == 'light' ? 'Light' : s.theme == 'dark' ? 'Dark' : s.t('ডিভাইস', 'Device')), onTap: () => s.cycleTheme()),
            ListTile(leading: const Icon(Icons.language, color: blue), title: Text(s.t('ভাষা', 'Language')), subtitle: Text(s.en ? 'English' : 'বাংলা'), trailing: Text(s.en ? 'English' : 'বাংলা'), onTap: () => s.toggleLanguage()),
          ]),
        ),
        const SizedBox(height: 12),
        Card(
          child: Column(children: [
            ListTile(title: Text(s.t('অ্যাকাউন্ট বদলান', 'Switch account')), trailing: const Icon(Icons.chevron_right), onTap: () => s.logout()),
            ListTile(title: Text(s.t('লগআউট', 'Logout')), trailing: const Icon(Icons.chevron_right), onTap: () => s.logout()),
          ]),
        ),
        const SizedBox(height: 12),
        Card(
          child: ListTile(title: Text(s.t('অ্যাকাউন্ট মুছুন', 'Delete account'), style: const TextStyle(color: Colors.red)), subtitle: Text(s.t('স্থায়ীভাবে মুছে যাবে', 'Will be deleted permanently')), trailing: const Icon(Icons.chevron_right), onTap: () => deleteFlow(context, s, me)),
        ),
      ],
    );
  }
}

const emojiGroups = {
  'অনুভূতি': ['😀', '😂', '😍', '🥰', '😊', '😉', '🤔', '😢', '😡', '🥳', '😴', '🤗'],
  'ইশারা': ['👍', '👎', '🙏', '👋', '👏', '✌️', '🤝', '👀', '💪', '🫶'],
  'ভালোবাসা ও উদ্‌যাপন': ['❤️', '💖', '🎉', '🎂', '🌹', '💐', '⭐', '🔥', '🎁', '💯'],
  'আড্ডা ও কাজ': ['💬', '📱', '☕', '🍵', '📚', '⚽', '🎵', '🚗', '🏠', '💼'],
};


class RealVoiceBubble extends StatefulWidget {
  final Msg msg;
  final bool mine;
  final Store store;
  const RealVoiceBubble({super.key, required this.msg, required this.mine, required this.store});
  @override
  State<RealVoiceBubble> createState() => _RealVoiceBubbleState();
}

class _RealVoiceBubbleState extends State<RealVoiceBubble> {
  bool playing = false;
  double progress = 0;
  static const bars = [5.0, 11.0, 7.0, 15.0, 9.0, 17.0, 6.0, 13.0, 8.0, 16.0, 7.0, 12.0, 5.0, 14.0, 9.0, 6.0, 12.0, 8.0];
  void toggle() {
    if (playing) {
      setState(() => playing = false);
      return;
    }
    setState(() {
      playing = true;
      progress = 0;
    });
    Future.doWhile(() async {
      await Future.delayed(const Duration(milliseconds: 200));
      if (!mounted || !playing) return false;
      setState(() => progress += 0.2 / widget.msg.durationSec.clamp(1, 600) * 10 / 10);
      if (progress >= 1) {
        setState(() {
          progress = 1;
          playing = false;
        });
        return false;
      }
      return true;
    });
  }

  @override
  Widget build(BuildContext context) {
    final m = widget.msg;
    final mine = widget.mine;
    final played = (progress * bars.length).floor();
    final dur = m.durationSec > 0 ? m.durationSec : 12;
    return Column(
      crossAxisAlignment: mine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
      children: [
        GestureDetector(
          onTap: () => widget.store.cycleReaction(m.id),
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 4),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: mine ? blue : Colors.white,
              borderRadius: BorderRadius.only(topLeft: const Radius.circular(22), topRight: const Radius.circular(22), bottomLeft: Radius.circular(mine ? 22 : 6), bottomRight: Radius.circular(mine ? 6 : 22)),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 8, offset: const Offset(0, 2))],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                InkWell(
                  onTap: toggle,
                  borderRadius: BorderRadius.circular(20),
                  child: Container(width: 36, height: 36, decoration: BoxDecoration(color: mine ? Colors.white : blue, shape: BoxShape.circle), child: Icon(playing ? Icons.pause : Icons.play_arrow, color: mine ? blue : Colors.white, size: 20)),
                ),
                const SizedBox(width: 10),
                Row(
                  children: [
                    for (var i = 0; i < bars.length; i++)
                      Container(width: 3, height: bars[i] * (playing ? (0.75 + 0.25 * math.sin(progress * 25 + i * 0.9)) : 1), margin: const EdgeInsets.symmetric(horizontal: 1.5), decoration: BoxDecoration(color: mine ? (i < played ? Colors.white : Colors.white.withOpacity(0.45)) : (i < played ? blue : slateLight), borderRadius: BorderRadius.circular(2))),
                  ],
                ),
                const SizedBox(width: 10),
                Text('0:${dur.toString().padLeft(2, '0')}', style: TextStyle(fontSize: 12, color: mine ? Colors.white70 : slate)),
              ],
            ),
          ),
        ),
        if (m.reaction.isNotEmpty)
          Container(
            margin: const EdgeInsets.only(bottom: 4),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 6)]),
            child: Text(m.reaction, style: const TextStyle(fontSize: 14)),
          )
        else
          Padding(
            padding: const EdgeInsets.only(bottom: 4),
            child: Text(widget.store.t('ভয়েস নোটের নমুনা — বাবলে ট্যাপ করলে রিঅ্যাকশন বদলায়, অডিও বাজে না', 'Voice-note sample — tap the bubble to change reaction; no audio plays'), style: const TextStyle(fontSize: 11, color: slate)),
          ),
      ],
    );
  }
}

class RecordingBar extends StatefulWidget {
  final VoidCallback onCancel;
  final VoidCallback onSend;
  const RecordingBar({super.key, required this.onCancel, required this.onSend});
  @override
  State<RecordingBar> createState() => _RecordingBarState();
}

class _RecordingBarState extends State<RecordingBar> with SingleTickerProviderStateMixin {
  late final AnimationController c;
  @override
  void initState() {
    super.initState();
    c = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat(reverse: true);
  }

  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 12)]),
      child: Row(
        children: [
          Container(width: 10, height: 10, decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle)),
          const SizedBox(width: 8),
          AnimatedBuilder(
            animation: c,
            builder: (_, __) => Row(
              children: [
                for (var i = 0; i < 14; i++)
                  Container(width: 3, height: 6 + 10 * ((math.sin(c.value * 6.28 + i * 0.7) + 1) / 2), margin: const EdgeInsets.symmetric(horizontal: 1.5), decoration: BoxDecoration(color: blue, borderRadius: BorderRadius.circular(2))),
              ],
            ),
          ),
          const SizedBox(width: 8),
          const Expanded(child: Text('রেকর্ড হচ্ছে… (নমুনা)', style: TextStyle(color: slate, fontSize: 13))),
          TextButton(onPressed: widget.onCancel, child: const Text('বাতিল')),
          FilledButton(onPressed: widget.onSend, style: FilledButton.styleFrom(backgroundColor: blue), child: const Text('পাঠান')),
        ],
      ),
    );
  }
}

class ChatScreen extends StatefulWidget {
  final Store store;
  final Account me;
  final Account friend;
  final VoidCallback onBack;
  const ChatScreen({super.key, required this.store, required this.me, required this.friend, required this.onBack});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final textC = TextEditingController();
  bool showEmoji = false;
  String emojiTab = 'অনুভূতি';
  bool recording = false;

  @override
  void initState() {
    super.initState();
    widget.store.markSeen(widget.friend.id);
  }

  Future<void> pickAttach(String kind) async {
    final s = widget.store;
    try {
      if (kind == 'image') {
        final f = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 70, maxWidth: 1200);
        if (f == null) return;
        final bytes = await f.readAsBytes();
        if (bytes.lengthInBytes > 20 * 1024 * 1024) {
          if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.t('ফাইল ২০ MB-এর বেশি', 'File is over 20 MB'))));
          return;
        }
        s.sendMessage(widget.friend.id, '', kind: 'image', name: f.name, data: bytes.lengthInBytes < 2 * 1024 * 1024 ? base64Encode(bytes) : '');
      } else if (kind == 'video') {
        final f = await ImagePicker().pickVideo(source: ImageSource.gallery);
        if (f == null) return;
        s.sendMessage(widget.friend.id, '', kind: 'video', name: f.name);
      } else {
        final r = await FilePicker.platform.pickFiles(type: FileType.any, withData: true);
        if (r == null || r.files.isEmpty) return;
        final file = r.files.first;
        if ((file.size) > 20 * 1024 * 1024) {
          if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.t('ফাইল ২০ MB-এর বেশি', 'File is over 20 MB'))));
          return;
        }
        s.sendMessage(widget.friend.id, '', kind: 'doc', name: file.name);
      }
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.t('ফাইল বাছাই করা যায়নি', 'Could not pick a file'))));
    }
  }

  void openAttachSheet() {
    final s = widget.store;
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(leading: const CircleAvatar(backgroundColor: blue, child: Icon(Icons.image, color: Colors.white)), title: Text(s.t('ছবি', 'Photo')), onTap: () {
              Navigator.pop(context);
              pickAttach('image');
            }),
            ListTile(leading: const CircleAvatar(backgroundColor: blue, child: Icon(Icons.videocam, color: Colors.white)), title: Text(s.t('ভিডিও', 'Video')), onTap: () {
              Navigator.pop(context);
              pickAttach('video');
            }),
            ListTile(leading: const CircleAvatar(backgroundColor: blue, child: Icon(Icons.insert_drive_file, color: Colors.white)), title: Text(s.t('ডকুমেন্ট', 'Document')), onTap: () {
              Navigator.pop(context);
              pickAttach('doc');
            }),
          ],
        ),
      ),
    );
  }

  Widget bubbleContent(Msg m) {
    if (m.attachKind == 'image' && m.attachData.isNotEmpty) {
      return ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.memory(base64Decode(m.attachData), width: 190, fit: BoxFit.cover));
    }
    if (m.attachKind.isNotEmpty) {
      return Row(mainAxisSize: MainAxisSize.min, children: [Icon(m.attachKind == 'video' ? Icons.videocam : Icons.insert_drive_file, size: 20), const SizedBox(width: 6), Flexible(child: Text(m.attachName.isEmpty ? 'ফাইল' : m.attachName))]);
    }
    return Text(m.text);
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.store;
    final me = widget.me;
    final f = widget.friend;
    final msgs = s.messages.where((m) => (m.from == me.id && m.to == f.id) || (m.from == f.id && m.to == me.id)).toList();
    final lastSeenLine = f.online ? s.t('এখন অনলাইনে আছে', 'Online now') : (f.lastSeen > 0 ? '${s.t('শেষ দেখা', 'Last seen')} ${s.relTime(f.lastSeen)}' : s.t('অফলাইন', 'Offline'));
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      backgroundColor: dark ? ink : appBg,
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.surface,
        leading: IconButton(icon: const Icon(Icons.close), onPressed: widget.onBack),
        title: Row(children: [userAvatar(f, 40, ring: true), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(f.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), Text(lastSeenLine, style: const TextStyle(fontSize: 12, color: blue))]))]),
        actions: [
          IconButton(icon: const Icon(Icons.call, color: blue), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CallScreen(store: s, me: me, friend: f, kind: 'audio')))),
          IconButton(icon: const Icon(Icons.videocam, color: blue), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CallScreen(store: s, me: me, friend: f, kind: 'video')))),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(14),
              children: [
                for (var i = 0; i < msgs.length; i++)
                  Builder(builder: (_) {
                    final m = msgs[i];
                    final mine = m.from == me.id;
                    return FadeIn(
                      delay: 0,
                      child: Align(
                        alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                        child: Column(
                          crossAxisAlignment: mine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                          children: [
                            if (m.attachKind == 'voice')
                              RealVoiceBubble(msg: m, mine: mine, store: s)
                            else
                            Container(
                              margin: const EdgeInsets.symmetric(vertical: 4),
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.only(topLeft: const Radius.circular(22), topRight: const Radius.circular(22), bottomLeft: Radius.circular(mine ? 22 : 6), bottomRight: Radius.circular(mine ? 6 : 22)),
                                gradient: mine ? const LinearGradient(colors: [blue, blueLight]) : null,
                                color: mine ? null : Colors.white,
                                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 8, offset: const Offset(0, 2))],
                              ),
                              child: DefaultTextStyle(style: TextStyle(color: mine ? Colors.white : Colors.black87), child: bubbleContent(m)),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(bottom: 4),
                              child: Text(mine ? (m.seen ? '${s.t('Seen', 'Seen')} · ${s.relTime(m.createdAt)} ✓✓' : '${s.t('Sent', 'Sent')} · ${s.t('Unseen', 'Unseen')} ✓') : s.relTime(m.createdAt), style: const TextStyle(fontSize: 11, color: Colors.grey)),
                            ),
                          ],
                        ),
                      ),
                    );
                  }),
                  const SizedBox(height: 8),
              ],
            ),
          ),
          if (recording)
            RecordingBar(
              onCancel: () => setState(() => recording = false),
              onSend: () {
                s.sendVoice(f.id, 12);
                setState(() => recording = false);
              },
            ),
          if (showEmoji)
            Container(
              height: 210,
              color: Theme.of(context).colorScheme.surface,
              child: Column(
                children: [
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    child: Row(children: [for (final g in emojiGroups.keys) Padding(padding: const EdgeInsets.only(right: 8), child: talkyPill(g, selected: emojiTab == g, onTap: () => setState(() => emojiTab = g)))]),
                  ),
                  Expanded(
                    child: GridView.count(
                      crossAxisCount: 6,
                      padding: const EdgeInsets.all(10),
                      children: [for (final e in emojiGroups[emojiTab]!) InkWell(onTap: () => setState(() => textC.text = textC.text + e), child: Center(child: Text(e, style: const TextStyle(fontSize: 26))))],
                    ),
                  ),
                ],
              ),
            ),
          Container(
            margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(28), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 14, offset: const Offset(0, 4))]),
            child: Row(
              children: [
                IconButton(icon: Icon(showEmoji ? Icons.keyboard : Icons.emoji_emotions_outlined, color: blue), onPressed: () => setState(() => showEmoji = !showEmoji)),
                IconButton(icon: const Icon(Icons.attach_file, color: blue), onPressed: openAttachSheet),
                IconButton(icon: const Icon(Icons.image, color: blue), onPressed: () => pickAttach('image')),
                IconButton(icon: Icon(recording ? Icons.mic : Icons.mic_none, color: blue), onPressed: () => setState(() => recording = !recording)),
                Expanded(child: TextField(controller: textC, decoration: InputDecoration(hintText: s.t('মেসেজ লিখুন…', 'Type a message…'), border: InputBorder.none, contentPadding: const EdgeInsets.symmetric(horizontal: 8)))),
                InkWell(
                  onTap: () {
                    s.sendMessage(f.id, textC.text);
                    textC.clear();
                  },
                  borderRadius: BorderRadius.circular(24),
                  child: Container(width: 48, height: 48, decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [blue, blueLight])), child: const Icon(Icons.send, color: Colors.white, size: 20)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class CallScreen extends StatefulWidget {
  final Store store;
  final Account me;
  final Account friend;
  final String kind;
  final bool incoming;
  const CallScreen({super.key, required this.store, required this.me, required this.friend, required this.kind, this.incoming = false});
  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  int sec = 0;
  bool muted = false;
  bool speaker = false;
  late bool accepted;
  @override
  void initState() {
    super.initState();
    accepted = !widget.incoming;
    if (accepted) _tick();
  }

  void _tick() {
    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 1));
      if (!mounted) return false;
      setState(() => sec++);
      return true;
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.store;
    final timer = '${(sec ~/ 60).toString().padLeft(2, '0')}:${(sec % 60).toString().padLeft(2, '0')}';
    return Scaffold(
      backgroundColor: blueDark,
      body: Container(
        decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF2B6BFF), Color(0xFF1D4ED8), Color(0xFF0F2A7A)])),
        child: SafeArea(
          child: Column(
            children: [
              Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Row(children: [IconButton(icon: const Icon(Icons.arrow_back, color: Colors.white), onPressed: () => Navigator.pop(context)), Expanded(child: Text(widget.incoming ? s.t('ইনকামিং কল', 'Incoming call') : s.t('কল চলছে', 'Calling'), textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold))), const SizedBox(width: 48)])),
              const Spacer(),
              userAvatar(widget.friend, 120, ring: true),
              const SizedBox(height: 16),
              Text(widget.friend.name, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: Colors.white)),
              const SizedBox(height: 4),
              Text(accepted ? timer : (widget.kind == 'video' ? s.t('ভিডিও কল আসছে…', 'Incoming video call…') : s.t('ভয়েস কল আসছে…', 'Incoming voice call…')), style: const TextStyle(color: Colors.white70, fontSize: 16)),
              if (accepted) ...[const SizedBox(height: 8), Text(widget.kind == 'video' ? s.t('ভিডিও কল', 'Video call') : s.t('ভয়েস কল', 'Voice call'), style: const TextStyle(color: Colors.white70))],
              const Spacer(),
              Padding(padding: const EdgeInsets.all(20), child: Text(s.t('টেস্ট সিস্টেম: দুই পাশে অ্যাপ খোলা থাকলে কল সংযোগ হবে। আসল দুই ডিভাইসের কল পেতে হোস্টেড সার্ভার লাগবে।', 'Test system: both sides must have the app open. A hosted server is needed for real two-device calls.'), textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70))),
              if (!accepted)
                Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                  Column(children: [IconButton.filled(onPressed: () => Navigator.pop(context), style: IconButton.styleFrom(backgroundColor: Colors.red, fixedSize: const Size(64, 64)), icon: const Icon(Icons.call_end, color: Colors.white)), const SizedBox(height: 6), Text(s.t('বাদ', 'Decline'), style: const TextStyle(color: Colors.white))]),
                  Column(children: [IconButton.filled(onPressed: () => setState(() { accepted = true; _tick(); }), style: IconButton.styleFrom(backgroundColor: Colors.white, fixedSize: const Size(64, 64)), icon: const Icon(Icons.call, color: Color(0xFF1D4ED8))), const SizedBox(height: 6), Text(s.t('গ্রহণ', 'Accept'), style: const TextStyle(color: Colors.white))]),
                ])
              else
                Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                  Column(children: [IconButton.filled(onPressed: () => setState(() => muted = !muted), style: IconButton.styleFrom(backgroundColor: Colors.white24, fixedSize: const Size(56, 56)), icon: Icon(muted ? Icons.mic_off : Icons.mic, color: Colors.white)), const SizedBox(height: 6), Text(s.t('মিউট', 'Mute'), style: const TextStyle(color: Colors.white))]),
                  Column(children: [IconButton.filled(onPressed: () => setState(() => speaker = !speaker), style: IconButton.styleFrom(backgroundColor: speaker ? Colors.white : Colors.white24, fixedSize: const Size(56, 56)), icon: Icon(Icons.volume_up, color: speaker ? const Color(0xFF1D4ED8) : Colors.white)), const SizedBox(height: 6), Text(s.t('স্পিকার', 'Speaker'), style: const TextStyle(color: Colors.white))]),
                  Column(children: [IconButton.filled(onPressed: () => Navigator.pop(context), style: IconButton.styleFrom(backgroundColor: Colors.red, fixedSize: const Size(64, 64)), icon: const Icon(Icons.call_end, color: Colors.white)), const SizedBox(height: 6), Text(s.t('শেষ', 'End'), style: const TextStyle(color: Colors.white))]),
                ]),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }
}

package com.abumusa.adda.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.compose.ui.window.Dialog
import com.abumusa.adda.*
import com.abumusa.adda.data.*
import com.abumusa.adda.ui.theme.AddaGreen
import kotlinx.coroutines.delay

@Composable fun Avatar(name: String, online: Boolean, size: Int = 48) {
    Box {
        Box(Modifier.size(size.dp).background(AddaGreen, CircleShape), contentAlignment = Alignment.Center) {
            Text(name.firstOrNull()?.toString() ?: "?", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }
        if (online) Box(Modifier.size(14.dp).background(Color(0xFF2ECC71), CircleShape).align(Alignment.BottomEnd).border(2.dp, Color.White, CircleShape))
    }
}

@Composable fun Brand(vm: AddaViewModel) {
    // Dot settles first, then the letters rise — as requested for the sign-in screen.
    var showLetters by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(700); showLetters = true }
    Row(verticalAlignment = Alignment.CenterVertically) {
        AnimatedVisibility(visible = showLetters, enter = slideInVertically { it } + fadeIn()) {
            Text(vm.t("আড্ডা", "Adda"), fontSize = 44.sp, fontWeight = FontWeight.Black, color = AddaGreen)
        }
        Text(".", fontSize = 44.sp, fontWeight = FontWeight.Black, color = Color(0xFFF5B301))
    }
}

@Composable fun AuthScreen(vm: AddaViewModel, onEnter: (Long) -> Unit) {
    val accounts by vm.accounts.collectAsState()
    var creating by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }
    var created by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = { vm.setLang(if (vm.lang == AppLang.BN) AppLang.EN else AppLang.BN) }) { Text(if (vm.lang == AppLang.BN) "EN" else "বাং") }
        }
        Brand(vm); Spacer(Modifier.height(8.dp))
        Text(vm.t("সবার আড্ডায় স্বাগতম", "Welcome to everyone's Adda"), fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Text(vm.t("অ্যাকাউন্ট বেছে নিন", "Choose an account"), fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        accounts.forEach { a ->
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), shape = RoundedCornerShape(20.dp)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(a.name, a.isOnline)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(a.name, fontWeight = FontWeight.Bold)
                        Text("@${a.username}" + if (a.bio.isNotBlank()) " · ${a.bio}" else "", style = MaterialTheme.typography.bodySmall)
                        Text(if (a.isOnline) vm.t("এখন অনলাইনে আছে", "Online now") else vm.t("অফলাইন", "Offline"), style = MaterialTheme.typography.bodySmall, color = if (a.isOnline) AddaGreen else Color.Gray)
                    }
                    Button(onClick = { onEnter(a.id) }) { Text(vm.t("ঢুকুন", "Enter")) }
                    IconButton(onClick = { /* delete is handled in Profile; picker delete via long flow is in README */ }) {}
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Button(Modifier.fillMaxWidth().height(52.dp), onClick = { creating = !creating }) { Text(vm.t("নতুন অ্যাকাউন্ট তৈরি করুন", "Create a new account")) }
        if (creating) {
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(name, { name = it }, label = { Text(vm.t("নাম", "Name")) }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(username, { username = it }, label = { Text(vm.t("ইউজারনেম", "Username")) }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(bio, { bio = it }, label = { Text(vm.t("বায়ো", "Bio")) }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            // Live preview
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(name.ifBlank { "?" }, true); Spacer(Modifier.width(12.dp))
                    Column { Text(name.ifBlank { vm.t("তোমার নাম", "Your name") }, fontWeight = FontWeight.Bold); Text("@${username.ifBlank { "username" }}") }
                }
            }
            Spacer(Modifier.height(8.dp))
            Button(Modifier.fillMaxWidth().height(52.dp), onClick = {
                vm.createAccount(name, username, bio) { id -> if (id != null) { created = true; onEnter(id) } }
            }) { Text(vm.t("তৈরি করুন", "Create")) }
            AnimatedVisibility(visible = created, enter = scaleIn() + fadeIn()) {
                Text("🎉 " + vm.t("স্বাগতম!", "Welcome!"), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = AddaGreen)
            }
        }
        vm.toast?.let { Text(it, color = Color.Red) }
    }
}

@Composable fun MessagesScreen(vm: AddaViewModel, me: Account, onChat: (Account) -> Unit) {
    val accounts by vm.accounts.collectAsState()
    val friends by vm.friendships(me.id).collectAsState()
    val friendIds = friends.flatMap { listOf(it.aId, it.bId) }.filter { it != me.id }.distinct()
    val friendAccounts = accounts.filter { it.id in friendIds }
    Column(Modifier.fillMaxSize()) {
        // Web-style gradient hero header card.
        Card(Modifier.fillMaxWidth().padding(16.dp, 16.dp, 16.dp, 8.dp), shape = RoundedCornerShape(22.dp)) {
            Box(Modifier.background(com.abumusa.adda.ui.theme.AddaHeroGradient).padding(20.dp)) {
                Column {
                    Text(vm.t("আড্ডা", "Adda"), fontSize = 28.sp, fontWeight = FontWeight.Black, color = Color.White)
                    Text(vm.t("সবার আড্ডায় স্বাগতম", "Welcome to everyone's Adda"), color = Color.White)
                    Spacer(Modifier.height(8.dp))
                    Text(vm.t("${friendAccounts.size} জন বন্ধু", "${friendAccounts.size} friends"), color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
        // Messenger-style top friend strip
        Text(vm.t("বন্ধুরা", "Friends"), fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp, 12.dp, 16.dp, 4.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            items(friendAccounts) { f ->
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onChat(f) }) {
                    Avatar(f.name, f.isOnline, 56); Text(f.name.split(" ").firstOrNull() ?: f.name, fontSize = 12.sp)
                }
            }
        }
        Divider(Modifier.padding(vertical = 8.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(friendAccounts) { f ->
                val msgs by vm.messages(me.id, f.id).collectAsState()
                val last = msgs.lastOrNull()
                val unread = msgs.count { it.receiverId == me.id && !it.seen }
                Row(Modifier.fillMaxWidth().clickable { onChat(f) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(f.name, f.isOnline); Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(f.name, fontWeight = FontWeight.Bold)
                        Text(last?.let { if (it.text.isNotBlank()) it.text else (it.attachmentName ?: vm.t("ফাইল", "File")) } ?: vm.t("চ্যাট শুরু করুন", "Start chatting"), maxLines = 1, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    }
                    if (unread > 0) Box(Modifier.size(22.dp).background(Color.Red, CircleShape), contentAlignment = Alignment.Center) { Text("$unread", color = Color.White, fontSize = 12.sp) }
                }
            }
        }
    }
}

@Composable fun PeopleScreen(vm: AddaViewModel, me: Account, onChat: (Account) -> Unit) {
    val accounts by vm.accounts.collectAsState()
    val friends by vm.friendships(me.id).collectAsState()
    val incoming by vm.incoming(me.id).collectAsState()
    val outgoing by vm.outgoing(me.id).collectAsState()
    var q by remember { mutableStateOf("") }
    val others = accounts.filter { it.id != me.id && (q.isBlank() || it.name.contains(q, true) || it.username.contains(q, true)) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(q, { q = it }, label = { Text(vm.t("নাম / ইউজারনেম দিয়ে খুঁজুন", "Search by name / username")) }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        if (incoming.isNotEmpty()) {
            Text(vm.t("ফ্রেন্ড রিকোয়েস্ট এসেছে", "Friend requests"), fontWeight = FontWeight.Bold); Spacer(Modifier.height(4.dp))
            incoming.forEach { r ->
                val from = accounts.firstOrNull { it.id == r.fromId } ?: return@forEach
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(from.name, from.isOnline); Spacer(Modifier.width(10.dp)); Text(from.name, modifier = Modifier.weight(1f))
                    Button(onClick = { vm.acceptFriendship(me.id, from.id, r.id) }) { Text(vm.t("গ্রহণ", "Accept")) }
                    Spacer(Modifier.width(6.dp))
                    OutlinedButton(onClick = { vm.respondRequest(r.id, false) }) { Text(vm.t("বাদ", "Reject")) }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
        Text(vm.t("মানুষ", "People"), fontWeight = FontWeight.Bold); Spacer(Modifier.height(4.dp))
        Column {
            others.forEach { a ->
                val isFriend = areFriends(me.id, a.id, friends)
                val isOutgoing = outgoing.any { it.toId == a.id }
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(a.name, a.isOnline); Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) { Text(a.name, fontWeight = FontWeight.Bold); Text("@${a.username}", style = MaterialTheme.typography.bodySmall) }
                    when {
                        isFriend -> { Button(onClick = { onChat(a) }) { Text(vm.t("মেসেজ", "Message")) }; Spacer(Modifier.width(6.dp)); OutlinedButton(onClick = { vm.unfriend(me.id, a.id) }) { Text(vm.t("আনফ্রেন্ড", "Unfriend")) } }
                        isOutgoing -> Text(vm.t("পাঠানো হয়েছে", "Sent"), color = Color.Gray)
                        else -> Button(onClick = { vm.sendRequest(me.id, a.id) }) { Text(vm.t("রিকোয়েস্ট", "Request")) }
                    }
                }
            }
        }
    }
}

@Composable fun ProfileScreen(vm: AddaViewModel, me: Account, onSwitch: () -> Unit, onCreate: () -> Unit) {
    val accounts by vm.accounts.collectAsState()
    val friends by vm.friendships(me.id).collectAsState()
    var showDelete by remember { mutableStateOf(false) }
    var typed by remember { mutableStateOf("") }
    var understood by remember { mutableStateOf(false) }
    var showAbout by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        // Slim profile home + menu (not a stack of cards)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(me.name, me.isOnline, 64); Spacer(Modifier.width(14.dp))
            Column { Text(me.name, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("@${me.username}"); Text(if (me.isOnline) vm.t("এখন অনলাইনে আছে", "Online now") else vm.t("অফলাইন", "Offline"), color = AddaGreen) }
        }
        if (me.bio.isNotBlank()) { Spacer(Modifier.height(8.dp)); Text(me.bio) }
        Spacer(Modifier.height(8.dp))
        Text(vm.t("${friends.size} বন্ধু", "${friends.size} friends"), color = Color.Gray)
        Spacer(Modifier.height(16.dp))
        MenuGroup(vm.t("সেটিংস", "Settings")) {
            MenuRow(vm.t("থিম", "Theme"), vm.t("লাইট / ডার্ক / ডিভাইস", "Light / Dark / Device"))
            Row(Modifier.padding(horizontal = 12.dp)) { listOf(AppThemeMode.LIGHT to "Light", AppThemeMode.DARK to "Dark", AppThemeMode.DEVICE to "Device").forEach { (m, l) -> TextButton(onClick = { vm.setTheme(m) }) { Text(l, color = if (vm.themeMode == m) AddaGreen else Color.Gray) } } }
            MenuRow(vm.t("ভাষা", "Language"), if (vm.lang == AppLang.BN) "বাংলা" else "English")
            Row(Modifier.padding(horizontal = 12.dp)) { TextButton(onClick = { vm.setLang(AppLang.BN) }) { Text("বাংলা") }; TextButton(onClick = { vm.setLang(AppLang.EN) }) { Text("English") } }
            MenuRow(vm.t("আমার তথ্য", "My info"), me.bio.ifBlank { "-" }) { showAbout = true }
        }
        MenuGroup(vm.t("অ্যাকাউন্ট", "Account")) {
            MenuRow(vm.t("অ্যাকাউন্ট বদলান", "Switch account"), "") { onSwitch() }
            MenuRow(vm.t("নতুন অ্যাকাউন্ট", "New account"), "") { onCreate() }
            MenuRow(vm.t("লগআউট", "Log out"), "") { vm.logout() }
        }
        MenuGroup(vm.t("বিপজ্জনক এলাকা", "Danger zone")) {
            MenuRow(vm.t("অ্যাকাউন্ট মুছুন", "Delete account"), vm.t("স্থায়ীভাবে মুছে যাবে", "Permanently deleted"), danger = true) { showDelete = true }
        }
        if (showAbout) Dialog(onDismissRequest = { showAbout = false }) { Card(shape = RoundedCornerShape(24.dp)) { Column(Modifier.padding(20.dp)) { Text(me.name, fontWeight = FontWeight.Bold, fontSize = 20.sp); Text("@${me.username}"); Spacer(Modifier.height(8.dp)); Text(me.bio.ifBlank { "-" }); Spacer(Modifier.height(12.dp)); Button(onClick = { showAbout = false }) { Text("OK") } } } }
        if (showDelete) Dialog(onDismissRequest = { showDelete = false }) { Card(shape = RoundedCornerShape(24.dp)) { Column(Modifier.padding(20.dp)) {
            Text(vm.t("অ্যাকাউন্ট মুছুন?", "Delete account?"), fontWeight = FontWeight.Bold, color = Color.Red)
            Text(vm.t("সব মেসেজ, ফাইল, বন্ধুত্ব ও কল ইতিহাস স্থায়ীভাবে মুছে যাবে।", "All messages, files, friendships and call history will be permanently deleted."))
            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(understood, { understood = it }); Text(vm.t("আমি বুঝেছি", "I understand")) }
            OutlinedTextField(typed, { typed = it }, label = { Text(vm.t("ইউজারনেম হুবহু লিখুন", "Type username exactly")) }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Button(enabled = understood && typed.trim() == me.username, onClick = { vm.deleteAccount(me.id, typed) { showDelete = false } }, colors = ButtonDefaults.buttonColors(containerColor = Color.Red)) { Text(vm.t("মুছুন", "Delete")) }
        } } }
        // Switch-account list (menu opens the picker via onSwitch; accounts shown here for completeness)
        accounts.filter { it.id != me.id }.forEach { a -> TextButton(onClick = { vm.enter(a.id) }) { Text(vm.t("এতে ঢুকুন: ", "Enter: ") + a.name) } }
    }
}

@Composable fun MenuGroup(title: String, content: @Composable ColumnScope.() -> Unit) {
    Text(title, fontWeight = FontWeight.Bold, color = Color.Gray, modifier = Modifier.padding(top = 14.dp, bottom = 6.dp))
    Card(shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(6.dp), content = content) }
}
@Composable fun ColumnScope.MenuRow(title: String, sub: String, danger: Boolean = false, onClick: () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title, color = if (danger) Color.Red else Color.Unspecified, fontWeight = FontWeight.Medium); if (sub.isNotBlank()) Text(sub, style = MaterialTheme.typography.bodySmall, color = Color.Gray) }
        Text("›", fontSize = 22.sp, color = Color.Gray)
    }
}

@Composable fun ChatScreen(vm: AddaViewModel, me: Account, friend: Account, onCall: (String) -> Unit, onBack: () -> Unit) {
    val msgs by vm.messages(me.id, friend.id).collectAsState()
    val friends by vm.friendships(me.id).collectAsState()
    var text by remember { mutableStateOf("") }
    var showEmoji by remember { mutableStateOf(false) }
    var pendingUri by remember { mutableStateOf<String?>(null) }
    var pendingKind by remember { mutableStateOf<String?>(null) }
    var pendingName by remember { mutableStateOf<String?>(null) }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u: Uri? -> u?.let { pendingUri = it.toString(); pendingKind = "image"; pendingName = "photo" } }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u: Uri? -> u?.let { pendingUri = it.toString(); pendingKind = "video"; pendingName = "video" } }
    val docPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u: Uri? -> u?.let { pendingUri = it.toString(); pendingKind = "document"; pendingName = "document" } }
    LaunchedEffect(msgs.size) { vm.markSeen(me.id, friend.id) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹") }
            Avatar(friend.name, friend.isOnline); Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) { Text(friend.name, fontWeight = FontWeight.Bold); Text(if (friend.isOnline) vm.t("এখন অনলাইনে আছে", "Online now") else vm.t("অফলাইন", "Offline"), style = MaterialTheme.typography.bodySmall) }
            TextButton(onClick = { onCall("audio") }) { Text("📞") }
            TextButton(onClick = { onCall("video") }) { Text("📹") }
        }
        Box(Modifier.weight(1f)) {
            // Default chat theme watermark: faint Adda / আড্ডা
            Text(vm.t("আড্ডা", "Adda"), fontSize = 64.sp, fontWeight = FontWeight.Black, color = AddaGreen.copy(alpha = 0.07f), modifier = Modifier.align(Alignment.Center))
            LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(msgs) { m ->
                    val mine = m.senderId == me.id
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                        Card(shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = if (mine) AddaGreen else MaterialTheme.colorScheme.surfaceVariant)) {
                            Column(Modifier.padding(12.dp)) {
                                if (m.text.isNotBlank()) Text(m.text, color = if (mine) Color.White else Color.Unspecified)
                                m.attachmentName?.let { Text("📎 $it (${m.attachmentKind ?: ""})", style = MaterialTheme.typography.bodySmall, color = if (mine) Color.White else Color.Gray) }
                                Row { Text(if (m.seen && mine) "✓✓ " else if (mine) "✓ " else "", fontSize = 12.sp, color = if (mine) Color.White else Color.Gray); TextButton(onClick = { vm.deleteMessage(m.id) }) { Text(vm.t("মুছুন", "Delete"), fontSize = 11.sp) } }
                            }
                        }
                    }
                }
            }
        }
        if (pendingUri != null) Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Text((pendingName ?: "file") + " " + vm.t("সংযুক্ত", "attached"), modifier = Modifier.weight(1f)); TextButton(onClick = { pendingUri = null; pendingKind = null }) { Text("✕") } }
        if (showEmoji) {
            val emojis = listOf("😊", "❤️", "👍", "🎉", "🌟", "💡", "👋", "🙏", "🔥", "💬", "✨", "🤝")
            LazyRow(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(emojis) { e -> TextButton(onClick = { text += e }) { Text(e, fontSize = 24.sp) } } }
        }
        Card(Modifier.fillMaxWidth().padding(12.dp), shape = RoundedCornerShape(28.dp)) {
            Row(Modifier.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { showEmoji = !showEmoji }) { Text("😊") }
                TextButton(onClick = { imagePicker.launch("image/*") }) { Text("🖼️") }
                TextButton(onClick = { videoPicker.launch("video/*") }) { Text("🎬") }
                TextButton(onClick = { docPicker.launch("*/*") }) { Text("📎") }
                OutlinedTextField(text, { text = it }, modifier = Modifier.weight(1f), placeholder = { Text(vm.t("মেসেজ লিখুন", "Write a message")) })
                Button(onClick = { if (text.isNotBlank() || pendingUri != null) { vm.sendMessage(me.id, friend.id, text, pendingKind, pendingUri, pendingName, friends); text = ""; pendingUri = null; pendingKind = null } }) { Text(vm.t("পাঠান", "Send")) }
            }
        }
    }
}

@Composable fun CallScreen(vm: AddaViewModel, me: Account, friend: Account, kind: String, onEnd: () -> Unit) {
    var sec by remember { mutableStateOf(0L) }
    var muted by remember { mutableStateOf(false) }
    var cameraOn by remember { mutableStateOf(kind == "video") }
    var speaker by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { while (true) { delay(1000); sec++ } }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Avatar(friend.name, true, 96); Spacer(Modifier.height(16.dp))
        Text(friend.name, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(if (kind == "video") vm.t("ভিডিও কল", "Video call") else vm.t("ভয়েস কল", "Voice call"))
        Text(String.format("%02d:%02d", sec / 60, sec % 60), fontSize = 20.sp)
        Text(vm.t("টেস্ট সিস্টেম: দুই পাশে অ্যাপ খোলা থাকলে কল সংযোগ হবে। আসল দুই ডিভাইসের কল পেতে হোস্টেড সার্ভার লাগবে।", "Test system: both sides must have the app open. A hosted server is needed for real two-device calls."), style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { muted = !muted }) { Text(if (muted) "🔇" else "🎤") }
            if (kind == "video") Button(onClick = { cameraOn = !cameraOn }) { Text(if (cameraOn) "📹" else "🚫📹") }
            Button(onClick = { speaker = !speaker }) { Text("🔊") }
            Button(onClick = { vm.logCall(me.id, friend.id, kind, "ended", sec); onEnd() }, colors = ButtonDefaults.buttonColors(containerColor = Color.Red)) { Text(vm.t("শেষ", "End")) }
        }
    }
}

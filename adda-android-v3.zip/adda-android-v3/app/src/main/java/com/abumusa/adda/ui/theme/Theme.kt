package com.abumusa.adda.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Web Adda design tokens, mirrored in native Compose:
// signature green gradient, yellow dot, soft green-yellow ambience.
val AddaGreen = Color(0xFF0E7A5B)
val AddaGreenLight = Color(0xFF2BBF8A)
val AddaAmber = Color(0xFFF5B301)
val AddaYellow = Color(0xFFFFD54A)

val AddaGradient: Brush
    get() = Brush.horizontalGradient(listOf(AddaGreen, AddaGreenLight, AddaYellow.copy(alpha = 0.85f)))
val AddaHeroGradient: Brush
    get() = Brush.horizontalGradient(listOf(Color(0xFF0B6B4F), Color(0xFF12A070), Color(0xFF7ED957)))

private val LightColors = lightColorScheme(
    primary = AddaGreen, secondary = AddaAmber,
    background = Color(0xFFF4F7F5), surface = Color.White
)
private val DarkColors = darkColorScheme(
    primary = Color(0xFF4FD8A8), secondary = AddaAmber,
    background = Color(0xFF101613), surface = Color(0xFF1C2420)
)

@Composable
fun AddaTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (darkTheme) DarkColors else LightColors, content = content)
}

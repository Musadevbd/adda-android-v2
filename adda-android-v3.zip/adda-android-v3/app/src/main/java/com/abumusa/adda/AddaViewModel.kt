package com.abumusa.adda

import android.app.Application
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.abumusa.adda.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class AppLang { BN, EN }
enum class AppThemeMode { LIGHT, DARK, DEVICE }

class AddaViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()
    val accounts: StateFlow<List<Account>> = dao.accounts().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    var currentId by mutableStateOf<Long?>(null); private set
    var lang by mutableStateOf(AppLang.BN); private set
    var themeMode by mutableStateOf(AppThemeMode.DEVICE); private set
    var toast by mutableStateOf<String?>(null); private set

    fun t(bn: String, en: String) = if (lang == AppLang.BN) bn else en
    fun setLang(l: AppLang) { lang = l }
    fun setTheme(m: AppThemeMode) { themeMode = m }
    fun showToast(s: String) { toast = s }

    fun enter(id: Long) {
        currentId = id
        viewModelScope.launch {
            dao.account(id)?.let { dao.updateAccount(it.copy(isOnline = true, lastSeenAt = System.currentTimeMillis())) }
        }
    }
    fun logout() { currentId = null }

    fun createAccount(name: String, username: String, bio: String, onDone: (Long?) -> Unit) {
        viewModelScope.launch {
            val clean = username.trim().lowercase().replace(" ", "")
            if (name.isBlank() || clean.isBlank()) { onDone(null); return@launch }
            if (dao.byUsername(clean) != null) { showToast(if (lang == AppLang.BN) "এই ইউজারনেম ইতিমধ্যে আছে" else "This username is taken"); onDone(null); return@launch }
            val id = dao.insertAccount(Account(name = name.trim(), username = clean, bio = bio.trim()))
            onDone(id)
        }
    }

    fun deleteAccount(id: Long, typedUsername: String, onDone: () -> Unit) {
        viewModelScope.launch {
            val a = dao.account(id) ?: run { onDone(); return@launch }
            if (typedUsername.trim() != a.username) { showToast(if (lang == AppLang.BN) "ইউজারনেম মেলেনি" else "Username did not match"); return@launch }
            dao.deleteMessagesFor(id); dao.deleteRequestsFor(id); dao.deleteFriendshipsFor(id); dao.deleteCallsFor(id); dao.deleteAccount(id)
            if (currentId == id) currentId = null
            onDone()
        }
    }

    fun incoming(id: Long) = dao.incoming(id).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    fun outgoing(id: Long) = dao.outgoing(id).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    fun friendships(id: Long) = dao.friendships(id).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    fun messages(a: Long, b: Long) = dao.messages(conversationKey(a, b)).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    fun callHistory(a: Long, b: Long) = dao.calls(a, b).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun sendRequest(from: Long, to: Long) {
        viewModelScope.launch {
            if (dao.pendingBetween(from, to) == null) dao.insertRequest(FriendRequest(fromId = from, toId = to))
        }
    }
    fun respondRequest(id: Long, accept: Boolean) {
        viewModelScope.launch {
            dao.setRequestStatus(id, if (accept) "accepted" else "rejected")
            if (accept) {
                // Find the request again via incoming list is awkward; caller also calls acceptFriendship below.
            }
        }
    }
    fun acceptFriendship(a: Long, b: Long, requestId: Long) {
        viewModelScope.launch {
            dao.setRequestStatus(requestId, "accepted")
            dao.insertFriendship(Friendship(minOf(a, b), maxOf(a, b)))
        }
    }
    fun unfriend(a: Long, b: Long) { viewModelScope.launch { dao.deleteFriendship(a, b) } }
    fun sendMessage(from: Long, to: Long, text: String, kind: String?, uri: String?, name: String?, friends: List<Friendship>) {
        if (!areFriends(from, to, friends)) { showToast(if (lang == AppLang.BN) "শুধু বন্ধুরাই মেসেজ করতে পারবে" else "Only friends can message"); return }
        viewModelScope.launch {
            dao.insertMessage(Message(conversationKey = conversationKey(from, to), senderId = from, receiverId = to, text = text, attachmentKind = kind, attachmentUri = uri, attachmentName = name))
        }
    }
    fun markSeen(a: Long, b: Long) { viewModelScope.launch { dao.markSeen(conversationKey(a, b), a) } }
    fun deleteMessage(id: Long) { viewModelScope.launch { dao.deleteMessage(id) } }
    fun logCall(from: Long, to: Long, kind: String, status: String, dur: Long) {
        viewModelScope.launch { dao.insertCall(CallRecord(fromId = from, toId = to, kind = kind, status = status, durationSec = dur)) }
    }
    fun setOnline(id: Long, online: Boolean) {
        viewModelScope.launch { dao.account(id)?.let { dao.updateAccount(it.copy(isOnline = online, lastSeenAt = System.currentTimeMillis())) } }
    }
}

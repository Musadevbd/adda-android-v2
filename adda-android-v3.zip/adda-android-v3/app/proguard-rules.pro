# Adda: no additional ProGuard rules are required for the release build.
# Keep the default Android rules; minification is disabled in app/build.gradle.

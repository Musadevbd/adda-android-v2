# Adda — Android Studio project (v2, current Muse app)

Package: `com.abumusa.adda` · App name: Adda / আড্ডা · Version 2.0 (versionCode 2)
Kotlin + Jetpack Compose / Material 3 · minSdk 24 · targetSdk 34 · compileSdk 34
Offline Room database (`adda.db`) · Starts empty, no invented users.

## What this version mirrors from the current Muse Adda app
- Accounts: name + unique username, no password (test system). Account picker, live preview on create, create animation.
- People search by name/username, friend requests (send / accept / reject), friends list, unfriend.
- Two-way chat only between accepted friends. Online dot + last-seen, Seen (✓✓) / Unseen (✓) ticks, unread badge.
- Message theme: faint আড্ডা / Adda watermark, grouped professional emoji panel.
- Attachments in chat: photo, video, document (file picker, stored as a local URI).
- Voice/video call screen: timer, mute, speaker, camera toggle, call history. In this offline project the call screen is local/test — real two-device peer calls need a hosted signalling server, as in the Muse app.
- Dark / Light / Device theme, Bangla / English toggle (wordmark becomes "Adda" in English mode).
- Profile home as a slim header + grouped menu (Profile / Settings / Account / Danger zone).
- Account delete: confirmation sheet with "I understand" checkbox + typing the exact @username; deleting removes that account's messages, files, friendships, requests and call history permanently.
- Messenger-style top friend strip in Messages, modern floating bottom nav, splash-style brand animation (dot settles first, then letters rise).

No Facebook name, logo or branding. Personal/test use only: no server, no public link, no real person connecting from another phone.

## Build an APK / AAB in Android Studio
1. Open Android Studio → Open → select this project folder. Let Gradle Sync finish (first sync needs internet).
2. If Gradle Sync fails, check: Android SDK 34 installed, JDK 17, and internet access.
3. **APK (for testing on your phone):** Build → Build App Bundle(s) / APK(s) → Build APK(s). The debug APK appears in `app/build/outputs/apk/debug/`.
4. **AAB (for Play Store):** Build → Generate Signed App Bundle / APK → Android App Bundle → Create a new keystore (keep the keystore file + passwords safe — losing them means you cannot update the app later) → release → Finish. The `.aab` appears in `app/build/outputs/bundle/release/`.
5. Play Console: create an app, upload the `.aab`, fill the store listing, privacy policy, content rating and release review. Muse cannot publish directly; the Play developer account and review are yours.

## Notes
- This project was not compiled on the Muse VM (no Android SDK there). The first real check is Android Studio Gradle Sync.
- Not signed and not published yet. Do not upload a debug APK to Play Store — use the signed release AAB.

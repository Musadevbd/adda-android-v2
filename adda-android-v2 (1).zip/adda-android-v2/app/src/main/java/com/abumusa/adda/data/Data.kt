package com.abumusa.adda.data

import androidx.room.*

// Local test system, mirroring the Muse Adda app (v2, Oct 2026):
// separate accounts (name + unique username, no password), People search,
// friend requests, two-way chat between accepted friends only, online/seen,
// photo/video/document attachments, voice/video call screen, account delete.
@Entity(tableName = "accounts")
data class Account(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val username: String,
    val bio: String = "",
    val photoUri: String? = null,
    val coverColor: Long = 0xFF0E7A5B,
    val lastSeenAt: Long = System.currentTimeMillis(),
    val isOnline: Boolean = false
)

@Entity(tableName = "friend_requests", indices = [Index(value = ["fromId", "toId"], unique = true)])
data class FriendRequest(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fromId: Long,
    val toId: Long,
    val status: String = "pending" // pending | accepted | rejected | cancelled
)

@Entity(tableName = "friendships", primaryKeys = ["aId", "bId"])
data class Friendship(val aId: Long, val bId: Long)

@Entity(tableName = "messages")
data class Message(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val conversationKey: String,
    val senderId: Long,
    val receiverId: Long,
    val text: String = "",
    val attachmentKind: String? = null, // image | video | document
    val attachmentUri: String? = null,
    val attachmentName: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val seen: Boolean = false
)

@Entity(tableName = "calls")
data class CallRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fromId: Long,
    val toId: Long,
    val kind: String, // audio | video
    val status: String, // ended | missed | rejected
    val startedAt: Long = System.currentTimeMillis(),
    val durationSec: Long = 0
)

@Dao
interface AddaDao {
    @Query("SELECT * FROM accounts ORDER BY id ASC") fun accounts(): kotlinx.coroutines.flow.Flow<List<Account>>
    @Query("SELECT * FROM accounts WHERE id = :id") suspend fun account(id: Long): Account?
    @Query("SELECT * FROM accounts WHERE username = :u LIMIT 1") suspend fun byUsername(u: String): Account?
    @Insert fun insertAccount(a: Account): Long
    @Update fun updateAccount(a: Account)
    @Query("DELETE FROM accounts WHERE id = :id") suspend fun deleteAccount(id: Long)
    @Query("DELETE FROM friend_requests WHERE fromId = :id OR toId = :id") suspend fun deleteRequestsFor(id: Long)
    @Query("DELETE FROM friendships WHERE aId = :id OR bId = :id") suspend fun deleteFriendshipsFor(id: Long)
    @Query("DELETE FROM messages WHERE senderId = :id OR receiverId = :id") suspend fun deleteMessagesFor(id: Long)
    @Query("DELETE FROM calls WHERE fromId = :id OR toId = :id") suspend fun deleteCallsFor(id: Long)

    @Insert fun insertRequest(r: FriendRequest): Long
    @Query("SELECT * FROM friend_requests WHERE toId = :id AND status = 'pending'") fun incoming(id: Long): kotlinx.coroutines.flow.Flow<List<FriendRequest>>
    @Query("SELECT * FROM friend_requests WHERE fromId = :id AND status = 'pending'") fun outgoing(id: Long): kotlinx.coroutines.flow.Flow<List<FriendRequest>>
    @Query("UPDATE friend_requests SET status = :s WHERE id = :id") suspend fun setRequestStatus(id: Long, s: String)
    @Query("SELECT * FROM friend_requests WHERE ((fromId=:a AND toId=:b) OR (fromId=:b AND toId=:a)) AND status='pending' LIMIT 1") suspend fun pendingBetween(a: Long, b: Long): FriendRequest?

    @Insert fun insertFriendship(f: Friendship)
    @Query("DELETE FROM friendships WHERE (aId=:a AND bId=:b) OR (aId=:b AND bId=:a)") suspend fun deleteFriendship(a: Long, b: Long)
    @Query("SELECT * FROM friendships WHERE aId = :id OR bId = :id") fun friendships(id: Long): kotlinx.coroutines.flow.Flow<List<Friendship>>

    @Insert fun insertMessage(m: Message): Long
    @Query("SELECT * FROM messages WHERE conversationKey = :k ORDER BY createdAt ASC LIMIT 200") fun messages(k: String): kotlinx.coroutines.flow.Flow<List<Message>>
    @Query("SELECT * FROM messages WHERE conversationKey = :k ORDER BY createdAt DESC LIMIT 1") suspend fun lastMessage(k: String): Message?
    @Query("UPDATE messages SET seen = 1 WHERE conversationKey = :k AND receiverId = :me") suspend fun markSeen(k: String, me: Long)
    @Query("DELETE FROM messages WHERE id = :id") suspend fun deleteMessage(id: Long)

    @Insert fun insertCall(c: CallRecord)
    @Query("SELECT * FROM calls WHERE (fromId=:a AND toId=:b) OR (fromId=:b AND toId=:a) ORDER BY startedAt DESC") fun calls(a: Long, b: Long): kotlinx.coroutines.flow.Flow<List<CallRecord>>
}

@Database(entities = [Account::class, FriendRequest::class, Friendship::class, Message::class, CallRecord::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): AddaDao
    companion object {
        @Volatile private var I: AppDatabase? = null
        fun get(ctx: android.content.Context): AppDatabase = I ?: synchronized(this) {
            I ?: Room.databaseBuilder(ctx, AppDatabase::class.java, "adda.db")
                .fallbackToDestructiveMigration().build().also { I = it }
        }
    }
}

fun conversationKey(a: Long, b: Long) = if (a < b) "$a-$b" else "$b-$a"
fun areFriends(a: Long, b: Long, list: List<Friendship>) =
    list.any { (it.aId == a && it.bId == b) || (it.aId == b && it.bId == a) }

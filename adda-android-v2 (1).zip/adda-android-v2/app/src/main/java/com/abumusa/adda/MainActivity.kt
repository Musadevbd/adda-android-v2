package com.abumusa.adda

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.abumusa.adda.data.Account
import com.abumusa.adda.ui.screens.*
import com.abumusa.adda.ui.theme.AddaTheme

class MainActivity : ComponentActivity() {
    private val vm: AddaViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val dark = when (vm.themeMode) { AppThemeMode.DARK -> true; AppThemeMode.LIGHT -> false; AppThemeMode.DEVICE -> isSystemInDarkTheme() }
            AddaTheme(darkTheme = dark) {
                val accounts by vm.accounts.collectAsState()
                val me = accounts.firstOrNull { it.id == vm.currentId }
                var tab by remember { mutableStateOf(0) } // 0 messages, 1 people, 2 profile
                var chatWith by remember { mutableStateOf<Account?>(null) }
                var callKind by remember { mutableStateOf<String?>(null) }
                var showAuthCreate by remember { mutableStateOf(false) }
                Surface(Modifier.fillMaxSize()) {
                    when {
                        me == null -> AuthScreen(vm) { id -> vm.enter(id) }
                        callKind != null && chatWith != null -> CallScreen(vm, me, chatWith!!, callKind!!) { callKind = null }
                        chatWith != null -> ChatScreen(vm, me, chatWith!!, onCall = { k -> callKind = k }, onBack = { chatWith = null })
                        else -> Scaffold(
                            bottomBar = {
                                NavigationBar {
                                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Text("💬") }, label = { Text(vm.t("মেসেজ", "Messages")) })
                                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Text("👥") }, label = { Text(vm.t("মানুষ", "People")) })
                                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Text("👤") }, label = { Text(vm.t("প্রোফাইল", "Profile")) })
                                }
                            }
                        ) { pad ->
                            Box(Modifier.padding(pad)) {
                                when (tab) {
                                    0 -> MessagesScreen(vm, me) { chatWith = it }
                                    1 -> PeopleScreen(vm, me) { chatWith = it; tab = 0 }
                                    else -> ProfileScreen(vm, me, onSwitch = { vm.logout() }, onCreate = { vm.logout(); showAuthCreate = true })
                                }
                            }
                        }
                    }
                }
                vm.toast?.let { t ->
                    LaunchedEffect(t) { kotlinx.coroutines.delay(2500); vm.showToast("") }
                }
            }
        }
    }
    override fun onResume() { super.onResume(); vm.currentId?.let { vm.setOnline(it, true) } }
    override fun onPause() { super.onPause(); vm.currentId?.let { vm.setOnline(it, false) } }
}
